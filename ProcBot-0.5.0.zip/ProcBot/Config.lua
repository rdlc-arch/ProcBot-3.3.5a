local ADDON, ns = ...
local C = {}
ns.Config = C

local uid = 0
local function N() uid = uid + 1; return "ProcBotUI" .. uid end

local BACKDROP = {
  bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
  edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
  tile = true, tileSize = 32, edgeSize = 32,
  insets = {left = 11, right = 12, top = 12, bottom = 11},
}
local BOX = {
  bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 12,
  insets = {left = 3, right = 3, top = 3, bottom = 3},
}

------------------------------------------------------------------------
-- Widget helpers
------------------------------------------------------------------------
local function Button(parent, text, w, h)
  local b = CreateFrame("Button", N(), parent, "UIPanelButtonTemplate")
  b:SetWidth(w or 110); b:SetHeight(h or 24)
  b:SetText(text)
  return b
end

local function Label(parent, text, font)
  local f = parent:CreateFontString(nil, "ARTWORK", font or "GameFontHighlight")
  f:SetJustifyH("LEFT")
  f:SetText(text or "")
  return f
end

local function Check(parent, text, onClick)
  local n = N()
  local c = CreateFrame("CheckButton", n, parent, "UICheckButtonTemplate")
  c:SetWidth(26); c:SetHeight(26)
  _G[n .. "Text"]:SetText(text or "")
  c:SetScript("OnClick", function(self) onClick(self:GetChecked() and true or false) end)
  return c
end

local function Tooltip(frame, text)
  frame:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(text, 1, 1, 1, 1, true)
    GameTooltip:Show()
  end)
  frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function Slider(parent, label, minv, maxv, step, fmt, get, set)
  local n = N()
  local s = CreateFrame("Slider", n, parent, "OptionsSliderTemplate")
  s:SetWidth(240)
  s:SetMinMaxValues(minv, maxv)
  s:SetValueStep(step)
  _G[n .. "Low"]:SetText("")
  _G[n .. "High"]:SetText("")
  local txt = _G[n .. "Text"]
  local function show(v) txt:SetText(label .. ": " .. fmt(v)) end
  s.refresh = function()
    local v = get()
    s.lock = true
    s:SetValue(v)
    s.lock = false
    show(v)
  end
  s:SetScript("OnValueChanged", function(self, v)
    v = math.floor(v / step + 0.5) * step
    show(v)
    if not self.lock then set(v) end
  end)
  s:EnableMouseWheel(true)
  s:SetScript("OnMouseWheel", function(self, d)
    local lo, hi = self:GetMinMaxValues()
    self:SetValue(math.max(lo, math.min(hi, self:GetValue() + d * step)))
  end)
  return s
end

local function OpenColor(c, hasAlpha, cb)
  local r, g, b, a = c[1], c[2], c[3], c[4] or 1
  local prev = {r, g, b, a}
  ColorPickerFrame:Hide()
  ColorPickerFrame.hasOpacity = hasAlpha
  ColorPickerFrame.opacity = 1 - a
  ColorPickerFrame.previousValues = prev
  local function apply()
    local nr, ng, nb = ColorPickerFrame:GetColorRGB()
    local na = hasAlpha and (1 - OpacitySliderFrame:GetValue()) or 1
    cb({nr, ng, nb, na})
  end
  ColorPickerFrame.func = apply
  ColorPickerFrame.opacityFunc = apply
  ColorPickerFrame.cancelFunc = function() cb(prev) end
  ColorPickerFrame:SetColorRGB(r, g, b)
  ShowUIPanel(ColorPickerFrame)
end

local function Swatch(parent, get, set, clear, hasAlpha)
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(22); b:SetHeight(22)
  local bg = b:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetTexture(0.8, 0.8, 0.8, 1)
  local t = b:CreateTexture(nil, "ARTWORK")
  t:SetPoint("TOPLEFT", 2, -2); t:SetPoint("BOTTOMRIGHT", -2, 2)
  t:SetTexture(1, 1, 1, 1)
  local x = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  x:SetPoint("CENTER"); x:SetText("-")
  b.refresh = function()
    local c = get()
    if c then t:SetVertexColor(c[1], c[2], c[3]); t:Show(); x:Hide()
    else t:Hide(); x:Show() end
  end
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:SetScript("OnClick", function(self, btn)
    if btn == "RightButton" and clear then clear(); b.refresh(); return end
    OpenColor(get() or {1, 1, 1, 1}, hasAlpha, function(nc) set(nc); b.refresh() end)
  end)
  return b
end

------------------------------------------------------------------------
-- Main window
------------------------------------------------------------------------
local frame, panels, tabs, current = nil, {}, {}, "layout"
local refreshers = {}

local function L() return ns.P.layout end
local function changed() ns:Refresh() end

local function selectTab(key)
  current = key
  for k, p in pairs(panels) do if k == key then p:Show() else p:Hide() end end
  for k, b in pairs(tabs) do if k == key then b:LockHighlight() else b:UnlockHighlight() end end
  C:RefreshIfShown()
end

local function buildLayout(p)
  local items = {}
  local function slider(col, row, ...)
    local s = Slider(p, ...)
    s:SetPoint("TOPLEFT", p, "TOPLEFT", col == 1 and 16 or 300, -24 - (row - 1) * 46)
    items[#items + 1] = s
    return s
  end
  local num = function(v) return tostring(math.floor(v + 0.5)) end
  local dec = function(v) return string.format("%.2f", v) end

  local frac = function(v) return "1/" .. num(v) .. " of a circle" end
  local pct = function(v) return string.format("%d%%", v * 100 + 0.5) end
  local rel = function() changed() end

  slider(1, 1, "Arc group height", -300, 300, 1, num, function() return L().arcY end, function(v) L().arcY = v; ns.Display:Position() end)
  slider(1, 2, "Side spacing (left/right)", 40, 300, 1, num, function() return L().spread end, function(v) L().spread = v; rel() end)
  slider(1, 3, "Side arc length", 4, 16, 1, frac, function() return L().sideFrac end, function(v) L().sideFrac = v; rel() end)
  slider(1, 4, "Side arc size", 0.5, 2, 0.05, pct, function() return L().sideScale end, function(v) L().sideScale = v; rel() end)
  slider(1, 5, "Lid spacing (top/bottom)", 30, 340, 1, num, function() return L().lidDist end, function(v) L().lidDist = v; rel() end)
  slider(1, 6, "Lid width", 1, 2.6, 0.05, dec, function() return L().lidWidth end, function(v) L().lidWidth = v; rel() end)
  slider(1, 7, "Lid arc length", 4, 16, 1, frac, function() return L().lidFrac end, function(v) L().lidFrac = v; rel() end)
  slider(1, 8, "Lid arc size", 0.5, 2, 0.05, pct, function() return L().lidScale end, function(v) L().lidScale = v; rel() end)
  slider(1, 9, "Overall arc scale", 0.5, 2, 0.05, pct, function() return L().scale end, function(v) L().scale = v; ns.Display:Position() end)

  slider(2, 1, "Icon size", 24, 80, 1, num, function() return L().iconSize end, function(v) L().iconSize = v; rel() end)
  slider(2, 2, "Icon spacing", 0, 20, 1, num, function() return L().iconGap end, function(v) L().iconGap = v; rel() end)
  slider(2, 3, "Icon height", -300, 500, 1, num, function() return L().iconY end, function(v) L().iconY = v; ns.Display:Position() end)
  slider(2, 4, "Opacity", 0.2, 1, 0.05, dec, function() return L().alpha end, function(v) L().alpha = v end)
  slider(2, 5, "Thickness", 4, 32, 1, num, function() return L().thick end, function(v) L().thick = v; rel() end)
  slider(2, 6, "Crescent taper", 0.4, 2, 0.05, dec, function() return L().taper end, function(v) L().taper = v; rel() end)
  slider(2, 7, "Ray count", 0, 40, 1, num, function() return L().rayCount end, function(v) L().rayCount = v; rel() end)
  slider(2, 8, "Ray length", 0.5, 4, 0.1, function(v) return string.format("%.1f", v) end,
    function() return L().rayLen end, function(v) L().rayLen = v; rel() end)

  local checks = {
    {"Only in combat", function() return ns.P.combatOnly end, function(v) ns.P.combatOnly = v end},
    {"Test mode (show everything)", function() return ns.P.test end, function(v) ns.P.test = v end},
    {"Unlock (drag arcs and icons)", function() return not ns.P.locked end, function(v) ns.P.locked = not v; ns.Display:Position() end},
    {"Pulse missing alerts", function() return L().pulse end, function(v) L().pulse = v end},
    {"Shimmering rays", function() return L().shimmer end, function(v) L().shimmer = v end},
  }
  for i, d in ipairs(checks) do
    local c = Check(p, d[1], function(v) d[3](v) end)
    local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
    c:SetPoint("TOPLEFT", p, "TOPLEFT", 12 + col * 190, -440 - row * 28)
    c.refresh = function() c:SetChecked(d[2]()) end
    items[#items + 1] = c
  end

  local reset = Button(p, "Reset layout", 130)
  reset:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 12, 8)
  reset:SetScript("OnClick", function() ns:ResetLayout() end)

  local hint = Label(p, "Arcs stay centered left and right. Use the height sliders or unlock and drag.", "GameFontDisableSmall")
  hint:SetPoint("BOTTOMLEFT", reset, "BOTTOMRIGHT", 12, 6)

  refreshers.layout = function() for _, w in ipairs(items) do w.refresh() end end
end

local function buildColors(p)
  local items = {}
  local order = {{"L", "Left arc (priority 1)"}, {"R", "Right arc (priority 2)"}, {"B", "Bottom arc (priority 3)"}, {"T", "Top arc (priority 4)"}}
  for i, d in ipairs(order) do
    local slot = d[1]
    local y = -28 - (i - 1) * 64
    local lab = Label(p, d[2], "GameFontNormal")
    lab:SetPoint("TOPLEFT", p, "TOPLEFT", 20, y)
    local sw = Swatch(p, function() return ns.P.colors[slot] end, function(c) ns.P.colors[slot] = c; changed() end, nil, true)
    sw:SetPoint("TOPLEFT", p, "TOPLEFT", 200, y + 4)
    items[#items + 1] = sw
    local s = Slider(p, "Brightness", 0.3, 1, 0.05, function(v) return string.format("%d%%", v * 100 + 0.5) end,
      function() return ns.P.weight[slot] end, function(v) ns.P.weight[slot] = v end)
    s:SetPoint("TOPLEFT", p, "TOPLEFT", 260, y)
    items[#items + 1] = s
  end
  local hint = Label(p, "Click a swatch to pick a color and opacity. Rules can override the color for a single ability in the Rules tab (right-click a rule swatch to clear it).", "GameFontDisableSmall")
  hint:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 16, 14)
  hint:SetWidth(540)
  refreshers.colors = function() for _, w in ipairs(items) do w.refresh() end end
end

------------------------------------------------------------------------
-- Rules tab
------------------------------------------------------------------------
local ruleSpec
local TYPE_HELP = {
  buff = "Shows while the buff is on you.",
  sdebuff = "Shows while this stacks on you.",
  missing = "Shows when the buff is missing or about to expire.",
  usable = "Shows when the ability is usable on your target.",
  cd = "Shows when the ability is off cooldown in combat.",
  tdebuff = "Shows when your debuff is missing on your target in combat.",
  tstack = "Builds up with your stacks on the target.",
  focus = "Shows when your buff is missing on your focus target.",
  fstack = "Builds up with your stacks on your focus target.",
  pet = "Shows when your pet is missing or dead.",
  weapon = "Shows when a weapon enchant is missing or the wrong one.",
  combo = "Builds up with combo points.",
  lust = "Shows in combat when it's ready and nobody is Sated or Exhausted.",
  totem = "Shows in combat when that totem isn't down.",
  item = "Shows out of combat when you have none in your bags.",
}

-- Shared dropdown menu, opened under the clicked button
local menuFrame = CreateFrame("Frame", "ProcBotMenu", UIParent, "UIDropDownMenuTemplate")
local function OpenMenu(anchor, items)
  CloseDropDownMenus()
  EasyMenu(items, menuFrame, anchor, 0, 0, "MENU")
end
C.OpenMenu = OpenMenu

local PLACES = {"L", "R", "B", "T", "I", "O"}
local PLACE_NAMES = {L = "Left arc", R = "Right arc", B = "Bottom arc", T = "Top arc", I = "Icon pop-up", O = "Off"}
local PLACE_SHORT = {L = "Left", R = "Right", B = "Bottom", T = "Top", I = "Icon", O = "|cff888888Off|r"}
C.PLACE_NAMES = PLACE_NAMES

local DOWN = " |TInterface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up:14:14:0:0|t"

local function sortedRules(spec)
  local list = {}
  for _, r in ipairs(ns:TabRules(spec)) do list[#list + 1] = {r = r, c = ns:Cfg(spec, r)} end
  table.sort(list, function(a, b) return a.c.prio < b.c.prio end)
  return list
end

local function moveRule(spec, list, i, dir)
  local j = i + dir
  if j < 1 or j > #list then return end
  local a, b = list[i], list[j]
  local pa, pb = a.c.prio, b.c.prio
  if pa == pb then pb = pa + dir end
  ns:RuleStore(spec, a.r, true).prio = pb
  ns:RuleStore(spec, b.r, true).prio = pa
  ns:Refresh()
end

local function buildRules(p)
  local specBtns = {}
  local tabsList = ns.SPEC_TABS[ns.class] or {"All"}
  local bw = math.floor(560 / #tabsList) - 4
  for i, spec in ipairs(tabsList) do
    local b = Button(p, spec, bw, 22)
    b:SetPoint("TOPLEFT", p, "TOPLEFT", 8 + (i - 1) * (bw + 4), -6)
    b:SetScript("OnClick", function() ruleSpec = spec; C:RefreshIfShown() end)
    specBtns[spec] = b
  end

  local head = {{"Ability", 8}, {"Shows on", 216}, {"Build-up", 306}, {"Color", 358}, {"Option", 394}, {"Order", 510}}
  for _, h in ipairs(head) do
    local f = Label(p, h[1], "GameFontNormalSmall")
    f:SetPoint("TOPLEFT", p, "TOPLEFT", h[2], -36)
  end

  local sf = CreateFrame("ScrollFrame", N(), p, "UIPanelScrollFrameTemplate")
  sf:SetPoint("TOPLEFT", p, "TOPLEFT", 4, -52)
  sf:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -28, 78)
  local child = CreateFrame("Frame", nil, sf)
  child:SetWidth(550); child:SetHeight(10)
  sf:SetScrollChild(child)

  local rows = {}
  local function getRow(i)
    if rows[i] then return rows[i] end
    local row = CreateFrame("Frame", nil, child)
    row:SetWidth(550); row:SetHeight(28)
    row:SetPoint("TOPLEFT", child, "TOPLEFT", 0, -(i - 1) * 28)
    local stripe = row:CreateTexture(nil, "BACKGROUND")
    stripe:SetAllPoints(); stripe:SetTexture(1, 1, 1, (i % 2 == 0) and 0.04 or 0)

    local nameBtn = CreateFrame("Frame", nil, row)
    nameBtn:SetPoint("LEFT", row, "LEFT", 4, 0); nameBtn:SetWidth(200); nameBtn:SetHeight(24)
    nameBtn:EnableMouse(true)
    row.name = Label(nameBtn, "", "GameFontHighlightSmall")
    row.name:SetAllPoints(); row.name:SetJustifyH("LEFT")
    nameBtn:SetScript("OnEnter", function(self)
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:SetText(row.r.n, 1, 1, 1)
      GameTooltip:AddLine(TYPE_HELP[row.r.t] or "", 0.8, 0.8, 0.8, true)
      if row.r.max then GameTooltip:AddLine("Build-up: the arc brightens per stack and is full at " .. row.r.max .. ".", 0.6, 0.8, 1, true) end
      if row.r.extra then GameTooltip:AddLine("Extra: added with an Extra picker below the list.", 0.4, 1, 0.4, true) end
      GameTooltip:Show()
    end)
    nameBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    row.slot = Button(row, "", 86, 22)
    row.slot:SetPoint("LEFT", row, "LEFT", 210, 0)
    row.slot:SetScript("OnClick", function(self)
      local items = {{text = "Show on", isTitle = 1, notCheckable = 1}}
      for _, v in ipairs(PLACES) do
        items[#items + 1] = {text = PLACE_NAMES[v], checked = (row.c.place == v),
          func = function() ns:SetPlace(row.spec, row.r, v); C:RefreshIfShown() end}
      end
      OpenMenu(self, items)
    end)

    row.glow = Check(row, "", function(v) ns:SetCfg(row.spec, row.r, "glow", v) end)
    row.glow:SetPoint("LEFT", row, "LEFT", 312, 0)
    Tooltip(row.glow, "Glow on build-up: show the arc faintly while stacks build. Off = only show at full stacks.")

    row.color = Swatch(row, function() return row.c.color end,
      function(c) ns:SetCfg(row.spec, row.r, "color", c); C:RefreshIfShown() end,
      function() ns:SetCfg(row.spec, row.r, "color", nil); C:RefreshIfShown() end, true)
    row.color:SetPoint("LEFT", row, "LEFT", 362, 0)

    row.choice = Button(row, "", 112, 22)
    row.choice:SetPoint("LEFT", row, "LEFT", 392, 0)
    row.choice:SetScript("OnClick", function(self)
      local items = {}
      for i, ch in ipairs(row.r.choices) do
        items[#items + 1] = {text = ch.label, checked = (row.c.choice == i),
          func = function() ns:SetCfg(row.spec, row.r, "choice", i); C:RefreshIfShown() end}
      end
      OpenMenu(self, items)
    end)

    row.up = CreateFrame("Button", N(), row, "UIPanelScrollUpButtonTemplate")
    row.up:SetPoint("LEFT", row, "LEFT", 512, 0)
    row.up:SetScript("OnClick", function() moveRule(row.spec, row.list, row.idx, -1); C:RefreshIfShown() end)
    row.down = CreateFrame("Button", N(), row, "UIPanelScrollDownButtonTemplate")
    row.down:SetPoint("LEFT", row.up, "RIGHT", 2, 0)
    row.down:SetScript("OnClick", function() moveRule(row.spec, row.list, row.idx, 1); C:RefreshIfShown() end)

    rows[i] = row
    return row
  end

  -- Extra pickers
  local exLabel = Label(p, "Extra abilities for this tab:", "GameFontNormalSmall")
  exLabel:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 10, 58)
  local exBtns = {}
  for i = 1, ns.EXTRA_SLOTS do
    local b = Button(p, "", 180, 22)
    b:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 8 + (i - 1) * 186, 32)
    b:SetScript("OnClick", function(self)
      local spec = ruleSpec
      local chosen = ns:GetExtras(spec)
      local items = {{text = "Extra " .. i, isTitle = 1, notCheckable = 1},
        {text = "None", checked = (chosen[i] == nil), func = function() ns:SetExtra(spec, i, nil); C:RefreshIfShown() end}}
      for _, r in ipairs(ns:ExtraPool(spec)) do
        local used = false
        for j = 1, ns.EXTRA_SLOTS do if j ~= i and chosen[j] == r then used = true end end
        items[#items + 1] = {text = r.n, checked = (chosen[i] == r), disabled = used and 1 or nil,
          func = function() ns:SetExtra(spec, i, r.id); C:RefreshIfShown() end}
      end
      OpenMenu(self, items)
    end)
    exBtns[i] = b
  end

  local note = Label(p, "", "GameFontDisableSmall")
  note:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 10, 10)

  refreshers.rules = function()
    if not ruleSpec then ruleSpec = ns.spec or "All" end
    for spec, b in pairs(specBtns) do
      local label = spec
      if spec == ns.spec then label = spec .. " *" end
      b:SetText(label)
      if spec == ruleSpec then b:LockHighlight() else b:UnlockHighlight() end
    end
    local list = sortedRules(ruleSpec)
    for i, e in ipairs(list) do
      local row = getRow(i)
      row.spec, row.r, row.c, row.list, row.idx = ruleSpec, e.r, e.c, list, i
      row.name:SetText((e.r.extra and "|cff66ff66+|r " or "") .. e.r.n)
      if e.c.on then row.name:SetTextColor(1, 1, 1) else row.name:SetTextColor(0.5, 0.5, 0.5) end
      row.slot:SetText((PLACE_SHORT[e.c.place] or "?") .. DOWN)
      if e.r.max and e.c.on then row.glow:Show(); row.glow:SetChecked(e.c.glow) else row.glow:Hide() end
      row.color.refresh()
      if e.r.choices then
        row.choice:SetText(e.r.choices[e.c.choice].label .. DOWN); row.choice:Show()
      else
        row.choice:Hide()
      end
      if i == 1 then row.up:Disable() else row.up:Enable() end
      if i == #list then row.down:Disable() else row.down:Enable() end
      row:Show()
    end
    for i = #list + 1, #rows do rows[i]:Hide() end
    child:SetHeight(math.max(10, #list * 28))
    local chosen = ns:GetExtras(ruleSpec)
    local pool = #ns:ExtraPool(ruleSpec)
    for i, b in ipairs(exBtns) do
      if pool == 0 then b:Hide() else
        b:SetText((chosen[i] and chosen[i].n or ("|cff888888Extra " .. i .. ": none|r")) .. DOWN)
        b:Show()
      end
    end
    if pool == 0 then exLabel:Hide() else exLabel:Show() end
    note:SetText("* = your active spec. + = extra. Order decides which rule wins when two share an arc, and which 4 icons show. \"All\" rules come after spec rules.")
    note:SetWidth(560)
  end
end

------------------------------------------------------------------------
-- Profiles tab
------------------------------------------------------------------------
StaticPopupDialogs["PROCBOT_NEWPROFILE"] = {
  text = "New profile name",
  button1 = ACCEPT, button2 = CANCEL,
  hasEditBox = 1, maxLetters = 48,
  OnShow = function(self) _G[self:GetName() .. "EditBox"]:SetText("") end,
  OnAccept = function(self, data)
    local name = _G[self:GetName() .. "EditBox"]:GetText()
    if not ns:NewProfile(name, data) then ns:Print("that name is empty or already used") end
  end,
  EditBoxOnEnterPressed = function(self)
    local parent = self:GetParent()
    if not ns:NewProfile(self:GetText(), parent.data) then ns:Print("that name is empty or already used") end
    parent:Hide()
  end,
  EditBoxOnEscapePressed = function(self) self:GetParent():Hide() end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["PROCBOT_DELETEPROFILE"] = {
  text = "Delete profile \"%s\"?",
  button1 = DELETE, button2 = CANCEL,
  OnAccept = function(self, data) ns:DeleteProfile(data); C:RefreshIfShown() end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["PROCBOT_RESETPROFILE"] = {
  text = "Reset the current profile to defaults? Layout, colors and all rule changes are cleared.",
  button1 = OKAY, button2 = CANCEL,
  OnAccept = function() ns:ResetProfile() end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}

local function buildProfiles(p)
  local t1 = Label(p, "Active profile", "GameFontNormal")
  t1:SetPoint("TOPLEFT", p, "TOPLEFT", 16, -16)

  local dd = CreateFrame("Frame", N(), p, "UIDropDownMenuTemplate")
  dd:SetPoint("TOPLEFT", p, "TOPLEFT", 0, -36)
  UIDropDownMenu_SetWidth(dd, 220)
  UIDropDownMenu_Initialize(dd, function(self, level)
    for _, name in ipairs(ns:ProfileList()) do
      local info = UIDropDownMenu_CreateInfo()
      info.text = name
      info.checked = (name == ns.profileName)
      info.func = function() ns:SetProfile(name); C:RefreshIfShown() end
      UIDropDownMenu_AddButton(info, level)
    end
  end)

  local del = Button(p, "Delete a profile", 140)
  del:SetPoint("LEFT", dd, "RIGHT", 0, 2)
  del:SetScript("OnClick", function(self)
    local menu = {}
    for _, name in ipairs(ns:ProfileList()) do
      if name ~= ns.profileName then
        menu[#menu + 1] = {text = name, notCheckable = 1, func = function()
          local dlg = StaticPopup_Show("PROCBOT_DELETEPROFILE", name)
          if dlg then dlg.data = name end
        end}
      end
    end
    if #menu == 0 then ns:Print("no other profiles to delete"); return end
    EasyMenu(menu, C.menuFrame, "cursor", 0, 0, "MENU")
  end)
  C.menuFrame = CreateFrame("Frame", N(), UIParent, "UIDropDownMenuTemplate")

  local new = Button(p, "New profile", 130)
  new:SetPoint("TOPLEFT", p, "TOPLEFT", 16, -76)
  new:SetScript("OnClick", function() local d = StaticPopup_Show("PROCBOT_NEWPROFILE"); if d then d.data = false end end)
  local cp = Button(p, "Copy to new profile", 160)
  cp:SetPoint("LEFT", new, "RIGHT", 8, 0)
  cp:SetScript("OnClick", function() local d = StaticPopup_Show("PROCBOT_NEWPROFILE"); if d then d.data = true end end)
  local rst = Button(p, "Reset profile", 130)
  rst:SetPoint("LEFT", cp, "RIGHT", 8, 0)
  rst:SetScript("OnClick", function() StaticPopup_Show("PROCBOT_RESETPROFILE") end)

  local info = Label(p, "", "GameFontDisableSmall")
  info:SetPoint("TOPLEFT", new, "BOTTOMLEFT", 0, -8)
  info:SetWidth(540)

  local t2 = Label(p, "Share settings", "GameFontNormal")
  t2:SetPoint("TOPLEFT", p, "TOPLEFT", 16, -160)
  local e1 = Button(p, "Export everything", 150)
  e1:SetPoint("TOPLEFT", t2, "BOTTOMLEFT", 0, -10)
  e1:SetScript("OnClick", function() C:ShowExport("all") end)
  local e2 = Button(p, "Export layout", 130)
  e2:SetPoint("LEFT", e1, "RIGHT", 8, 0)
  e2:SetScript("OnClick", function() C:ShowExport("layout") end)
  local e3 = Button(p, "Export class rules", 150)
  e3:SetPoint("LEFT", e2, "RIGHT", 8, 0)
  e3:SetScript("OnClick", function() C:ShowExport("rules") end)
  local im = Button(p, "Import string", 150)
  im:SetPoint("TOPLEFT", e1, "BOTTOMLEFT", 0, -8)
  im:SetScript("OnClick", function() C:ShowImport() end)

  local help = Label(p, "Export gives you a text string to copy (Ctrl+C). Paste it into Import on another character, account or device. " ..
    "If pasting doesn't work on Android, copy the file WTF\\Account\\<ACCOUNT>\\SavedVariables\\ProcBot.lua instead; it holds every profile.", "GameFontDisableSmall")
  help:SetPoint("TOPLEFT", im, "BOTTOMLEFT", 0, -14)
  help:SetWidth(540)

  refreshers.profiles = function()
    UIDropDownMenu_SetText(dd, ns.profileName)
    local users = {}
    for char, pn in pairs(ProcBotDB.chars) do if pn == ns.profileName then users[#users + 1] = char end end
    info:SetText("Used by: " .. table.concat(users, ", "))
  end
end

------------------------------------------------------------------------
-- Import / export window
------------------------------------------------------------------------
local io, ioMode, ioParsed
local function buildIO()
  io = CreateFrame("Frame", "ProcBotIO", UIParent)
  io:SetWidth(520); io:SetHeight(340)
  io:SetPoint("CENTER")
  io:SetFrameStrata("FULLSCREEN_DIALOG")
  io:SetBackdrop(BACKDROP)
  io:EnableMouse(true); io:SetMovable(true)
  io:RegisterForDrag("LeftButton")
  io:SetScript("OnDragStart", io.StartMoving)
  io:SetScript("OnDragStop", io.StopMovingOrSizing)
  tinsert(UISpecialFrames, "ProcBotIO")

  io.title = Label(io, "", "GameFontNormalLarge")
  io.title:SetPoint("TOP", io, "TOP", 0, -18)
  local close = CreateFrame("Button", nil, io, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", io, "TOPRIGHT", -6, -6)

  local box = CreateFrame("Frame", nil, io)
  box:SetPoint("TOPLEFT", io, "TOPLEFT", 20, -46)
  box:SetPoint("BOTTOMRIGHT", io, "BOTTOMRIGHT", -20, 80)
  box:SetBackdrop(BOX)
  box:SetBackdropColor(0, 0, 0, 0.6)

  local sf = CreateFrame("ScrollFrame", "ProcBotIOScroll", box, "UIPanelScrollFrameTemplate")
  sf:SetPoint("TOPLEFT", box, "TOPLEFT", 8, -8)
  sf:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -28, 8)
  local eb = CreateFrame("EditBox", "ProcBotIOEdit", sf)
  eb:SetMultiLine(true)
  eb:SetMaxLetters(0)
  eb:SetAutoFocus(false)
  eb:SetFontObject(ChatFontNormal)
  eb:SetWidth(430)
  eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  eb:SetScript("OnTextChanged", function(self, user)
    if ioMode == "import" and user then C:CheckImport() end
  end)
  sf:SetScrollChild(eb)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() eb:SetFocus() end)
  io.edit = eb

  io.status = Label(io, "", "GameFontHighlightSmall")
  io.status:SetPoint("BOTTOMLEFT", io, "BOTTOMLEFT", 22, 52)
  io.status:SetWidth(470)

  io.btnNew = Button(io, "Import as new profile", 170)
  io.btnNew:SetPoint("BOTTOMLEFT", io, "BOTTOMLEFT", 20, 18)
  io.btnNew:SetScript("OnClick", function()
    if ioParsed then local n = ns:ApplyImport(ioParsed, true); ns:Print("imported as \"" .. n .. "\""); io:Hide() end
  end)
  io.btnOver = Button(io, "Overwrite current", 150)
  io.btnOver:SetPoint("LEFT", io.btnNew, "RIGHT", 8, 0)
  io.btnOver:SetScript("OnClick", function()
    if ioParsed then ns:ApplyImport(ioParsed, false); ns:Print("imported into \"" .. ns.profileName .. "\""); io:Hide() end
  end)
  io.btnSel = Button(io, "Select all", 110)
  io.btnSel:SetPoint("BOTTOMLEFT", io, "BOTTOMLEFT", 20, 18)
  io.btnSel:SetScript("OnClick", function() eb:SetFocus(); eb:HighlightText() end)
  io:Hide()
end

function C:CheckImport()
  local t, err = ns:ReadImport(io.edit:GetText())
  ioParsed = t
  if t then
    io.status:SetText("|cff66ff66" .. ns:DescribeImport(t) .. "|r")
    io.btnNew:Enable(); io.btnOver:Enable()
  else
    local txt = io.edit:GetText()
    io.status:SetText(txt:match("%S") and ("|cffff6666" .. (err or "Can't read this string") .. "|r") or "Paste a ProcBot string (Ctrl+V)")
    io.btnNew:Disable(); io.btnOver:Disable()
  end
end

function C:ShowExport(kind)
  if not io then buildIO() end
  ioMode = "export"
  local names = {all = "Export everything", layout = "Export layout", rules = "Export class rules"}
  io.title:SetText(names[kind] or "Export")
  local s = ns:Export(kind)
  io.edit:SetText(s)
  io.status:SetText(#s .. " characters. Press Ctrl+C to copy.")
  io.btnNew:Hide(); io.btnOver:Hide(); io.btnSel:Show()
  io:Show()
  io.edit:SetFocus(); io.edit:HighlightText()
end

function C:ShowImport()
  if not io then buildIO() end
  ioMode = "import"
  io.title:SetText("Import string")
  io.edit:SetText("")
  io.btnNew:Show(); io.btnOver:Show(); io.btnSel:Hide()
  io:Show()
  io.edit:SetFocus()
  C:CheckImport()
end

------------------------------------------------------------------------
-- Spec picker (shown when the spec can't be read from talents)
------------------------------------------------------------------------
local picker
function C:ShowSpecPicker()
  local tabs = ns.SPECS[ns.class]
  if not tabs then return end
  if not picker then
    picker = CreateFrame("Frame", "ProcBotSpecPicker", UIParent)
    picker:SetWidth(460); picker:SetHeight(140)
    picker:SetPoint("TOP", UIParent, "TOP", 0, -160)
    picker:SetFrameStrata("FULLSCREEN_DIALOG")
    picker:SetBackdrop(BACKDROP)
    picker:EnableMouse(true)
    tinsert(UISpecialFrames, "ProcBotSpecPicker")
    picker.text = Label(picker, "", "GameFontHighlight")
    picker.text:SetPoint("TOP", picker, "TOP", 0, -24)
    picker.text:SetWidth(420)
    picker.text:SetJustifyH("CENTER")
    picker.btns = {}
    for i = 1, 3 do
      local b = Button(picker, "", 130, 30)
      b:SetPoint("TOPLEFT", picker, "TOPLEFT", 26 + (i - 1) * 140, -58)
      b:SetScript("OnClick", function() ns:ChooseSpec(i); picker:Hide() end)
      picker.btns[i] = b
    end
    local later = Button(picker, "Not now", 100, 22)
    later:SetPoint("BOTTOM", picker, "BOTTOM", 0, 16)
    later:SetScript("OnClick", function() picker:Hide() end)
  end
  picker.text:SetText("ProcBot: which spec are you playing on this talent set?")
  for i = 1, 3 do picker.btns[i]:SetText(tabs[i] or tostring(i)) end
  picker:Show()
end

------------------------------------------------------------------------
-- Window
------------------------------------------------------------------------
function C:Build()
  frame = CreateFrame("Frame", "ProcBotConfig", UIParent)
  frame:SetWidth(620); frame:SetHeight(660)
  frame:SetPoint("CENTER")
  frame:SetFrameStrata("DIALOG")
  frame:SetToplevel(true)
  frame:SetClampedToScreen(true)
  frame:SetBackdrop(BACKDROP)
  frame:EnableMouse(true); frame:SetMovable(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", frame.StartMoving)
  frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
  tinsert(UISpecialFrames, "ProcBotConfig")

  local title = Label(frame, "ProcBot", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -18)
  frame.sub = Label(frame, "", "GameFontHighlightSmall")
  frame.sub:SetPoint("LEFT", title, "RIGHT", 12, 0)
  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)
  local specBtn = Button(frame, "Spec", 60, 24)
  specBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -20, -45)
  frame.onoff = Button(frame, "", 80, 24)
  frame.onoff:SetPoint("RIGHT", specBtn, "LEFT", -6, 0)
  frame.onoff:SetScript("OnClick", function() ns:SetEnabled(not ns:IsEnabled()) end)
  Tooltip(frame.onoff, "Turn ProcBot on or off on all characters (/pb enable, /pb disable).")
  specBtn:SetScript("OnClick", function() C:ShowSpecPicker() end)
  Tooltip(specBtn, "Choose your spec if ProcBot shows the wrong one or none.")

  local defs = {{"layout", "Layout", buildLayout}, {"colors", "Colors", buildColors}, {"rules", "Rules", buildRules}, {"profiles", "Profiles", buildProfiles}}
  for i, d in ipairs(defs) do
    local b = Button(frame, d[2], 100, 26)
    b:SetPoint("TOPLEFT", frame, "TOPLEFT", 20 + (i - 1) * 104, -44)
    b:SetScript("OnClick", function() selectTab(d[1]) end)
    tabs[d[1]] = b
    local p = CreateFrame("Frame", nil, frame)
    p:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -76)
    p:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -16, 16)
    p:SetBackdrop(BOX)
    p:SetBackdropColor(0, 0, 0, 0.35)
    p:Hide()
    panels[d[1]] = p
    d[3](p)
  end
  frame:SetScript("OnShow", function() C:RefreshIfShown() end)
  frame:Hide()
  selectTab("layout")
end

function C:RefreshIfShown()
  if not frame or not frame:IsShown() then return end
  frame.onoff:SetText(ns:IsEnabled() and "Disable" or "|cff66ff66Enable|r")
  frame.sub:SetText("v" .. ns.version .. "   " .. tostring(ns.class) .. " / " .. tostring(ns.spec or "no spec") .. "   profile: " .. tostring(ns.profileName))
  if refreshers[current] then refreshers[current]() end
end

function C:Toggle(show)
  if not frame then self:Build() end
  if show == nil then show = not frame:IsShown() end
  if show then frame:Show() else frame:Hide() end
end

function C:BuildOptionsEntry()
  local panel = CreateFrame("Frame")
  panel.name = "ProcBot"
  local t = Label(panel, "ProcBot", "GameFontNormalLarge")
  t:SetPoint("TOPLEFT", 16, -16)
  local d = Label(panel, "Proc and buff alerts. All settings are in the ProcBot window (/pb).", "GameFontHighlightSmall")
  d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -8)
  local b = Button(panel, "Open ProcBot", 160, 26)
  b:SetPoint("TOPLEFT", d, "BOTTOMLEFT", 0, -12)
  b:SetScript("OnClick", function()
    InterfaceOptionsFrame:Hide()
    HideUIPanel(GameMenuFrame)
    C:Toggle(true)
  end)
  InterfaceOptions_AddCategory(panel)
end

local ADDON, ns = ...
ProcBot = ns
ns.version = "0.5.0"

ns.ARCS = {"L", "R", "B", "T"}
ns.SLOT_CYCLE = {"L", "R", "B", "T", "I"}
ns.SLOT_NAMES = {L = "Left arc", R = "Right arc", B = "Bottom arc", T = "Top arc", I = "Icon pop-up"}
ns.SLOT_SHORT = {L = "Left", R = "Right", B = "Bottom", T = "Top", I = "Icon"}

ns.defaults = {
  combatOnly = true,   -- show alerts only while in combat
  locked = true,
  test = false,
  layout = {
    arcY = -20,       -- arc group offset from screen center
    spread = 110,     -- side spacing: iris circle radius (left/right arcs)
    sideFrac = 8,     -- side arc length: 1/sideFrac of the iris circle
    scale = 1,        -- overall scale of the whole arc group (spacing, length, thickness)
    sideScale = 1,    -- side arc size: length, thickness, glow and rays together
    lidDist = 128,    -- lid spacing: distance of top/bottom arcs from the center
    lidWidth = 1.8,   -- lid curve width, times the side spacing
    lidFrac = 8,      -- lid arc length: 1/lidFrac of the iris circle
    lidScale = 1,     -- lid arc size: length, thickness, glow and rays together
    thick = 12,       -- base arc thickness
    taper = 0.9,      -- crescent shape: higher = thinner toward the points
    rayCount = 18,    -- rays per arc
    rayLen = 2.2,     -- ray length, times the thickness
    shimmer = true,   -- rays fade in and out
    iconSize = 44,
    iconGap = 6,
    iconY = 154,      -- icon row offset from screen center (set to 2/5 of center-to-top at first login)
    alpha = 1,
    pulse = true,
  },
  colors = {
    L = {0.37, 0.71, 1.00, 1},
    R = {0.18, 0.44, 1.00, 1},
    B = {0.95, 0.69, 0.20, 1},
    T = {1.00, 0.35, 0.24, 1},
  },
  weight = {L = 1, R = 1, B = 0.8, T = 0.8},
  rules = {},
}

local function fill(dst, src)
  for k, v in pairs(src) do
    if type(v) == "table" then
      if type(dst[k]) ~= "table" then dst[k] = {} end
      fill(dst[k], v)
    elseif type(dst[k]) ~= type(v) then
      dst[k] = v
    end
  end
end
ns.Fill = fill

local function copy(v, depth)
  depth = depth or 0
  if type(v) ~= "table" or depth > 20 then return v end
  local t = {}
  for k, x in pairs(v) do
    local kt, xt = type(k), type(x)
    if (kt == "string" or kt == "number") and (xt == "string" or xt == "number" or xt == "boolean" or xt == "table") then
      t[k] = copy(x, depth + 1)
    end
  end
  return t
end
ns.Copy = copy

function ns:Print(msg)
  DEFAULT_CHAT_FRAME:AddMessage("|cff33ccffProcBot|r: " .. tostring(msg))
end

------------------------------------------------------------------------
-- Profiles
------------------------------------------------------------------------
local function migrate(p)
  local L = p.layout
  if type(L) ~= "table" then return end
  -- 0.1/0.2: one arc length and a lid gap relative to the iris
  if type(L.arcFrac) == "number" then
    if L.sideFrac == nil then L.sideFrac = L.arcFrac end
    if L.lidFrac == nil then L.lidFrac = L.arcFrac end
    L.arcFrac = nil
  end
  if type(L.lidGap) == "number" then
    if L.lidDist == nil then L.lidDist = math.floor((L.spread or 110) * L.lidGap + 0.5) end
    L.lidGap = nil
  end
end
ns.Migrate = migrate

function ns:UseProfile(name)
  local db = ProcBotDB
  if not db.profiles[name] then db.profiles[name] = {} end
  local p = db.profiles[name]
  migrate(p)
  fill(p, ns.defaults)
  self.P = p
  self.profileName = name
  db.chars[self.charKey] = name
end

function ns:ProfileList()
  local t = {}
  for name in pairs(ProcBotDB.profiles) do t[#t + 1] = name end
  table.sort(t)
  return t
end

function ns:UniqueName(base)
  local name, i = base, 2
  while ProcBotDB.profiles[name] do name = base .. " " .. i; i = i + 1 end
  return name
end

function ns:NewProfile(name, copyCurrent)
  if not name or name == "" then return false end
  if ProcBotDB.profiles[name] then return false end
  ProcBotDB.profiles[name] = copyCurrent and copy(self.P) or {}
  self:SetProfile(name)
  return true
end

function ns:SetProfile(name)
  self:UseProfile(name)
  self:Refresh()
end

function ns:DeleteProfile(name)
  if name == self.profileName then return false end
  ProcBotDB.profiles[name] = nil
  for char, pn in pairs(ProcBotDB.chars) do
    if pn == name then ProcBotDB.chars[char] = nil end
  end
  return true
end

function ns:ResetProfile()
  for k in pairs(self.P) do self.P[k] = nil end
  fill(self.P, ns.defaults)
  self:Refresh()
end

-- Account-wide master switch (all characters and profiles)
function ns:IsEnabled() return not ProcBotDB.disabled end
function ns:SetEnabled(on)
  ProcBotDB.disabled = not on
  self:Print(on and "enabled" or "disabled (type /pb enable to turn it back on)")
  if not on then self.Display:HideAll() end
  self:Refresh()
end

function ns:ResetLayout()
  self.P.layout, self.P.colors, self.P.weight = nil, nil, nil
  fill(self.P, ns.defaults)
  self:Refresh()
end

------------------------------------------------------------------------
-- Per-rule settings (only overrides are stored)
------------------------------------------------------------------------
function ns:RuleSpecTable(spec, create)
  local R = self.P.rules
  local cl = R[self.class]
  if not cl then if not create then return end cl = {}; R[self.class] = cl end
  local sp = cl[spec]
  if not sp then if not create then return end sp = {}; cl[spec] = sp end
  return sp
end

function ns:RuleStore(spec, r, create)
  local sp = self:RuleSpecTable(spec, create)
  if not sp then return end
  local t = sp[r.id]
  if not t and create then t = {}; sp[r.id] = t end
  return t
end

function ns:Cfg(spec, r)
  local t = self:RuleStore(spec, r, false) or {}
  local c = {}
  if t.on == nil then c.on = not r.off else c.on = t.on end
  c.slot = t.slot or r.slot
  if c.slot == "O" then c.on = false end
  c.place = c.on and c.slot or "O"   -- what the placement dropdown shows
  if t.glow == nil then c.glow = true else c.glow = t.glow end
  c.color = t.color
  c.prio = t.prio or r.defPrio
  c.choice = t.choice or r.choice or 1
  if r.choices and not r.choices[c.choice] then c.choice = 1 end
  return c
end

-- Placement dropdown: L/R/B/T/I, or O = off
function ns:SetPlace(spec, r, v)
  local t = self:RuleStore(spec, r, true)
  if v == "O" then
    t.on = false
  else
    t.on = true
    t.slot = v
  end
  self:Refresh()
end

-- Extra picker slots (ids of ExtraData rules)
function ns:ExtraPool(spec)
  local d = ns.ExtraData and ns.ExtraData[self.class]
  return d and d[spec] or {}
end

function ns:ExtraRule(spec, id)
  for _, r in ipairs(self:ExtraPool(spec)) do
    if r.id == id then return r end
  end
end

function ns:GetExtras(spec)
  local sp = self:RuleSpecTable(spec, false)
  local t = sp and sp._extras
  local out = {}
  for i = 1, ns.EXTRA_SLOTS do
    local id = t and t[i]
    out[i] = (type(id) == "string" and self:ExtraRule(spec, id)) or nil
  end
  return out
end

function ns:SetExtra(spec, i, id)
  local sp = self:RuleSpecTable(spec, true)
  sp._extras = type(sp._extras) == "table" and sp._extras or {}
  if id then
    for j = 1, ns.EXTRA_SLOTS do if sp._extras[j] == id then sp._extras[j] = false end end
  end
  sp._extras[i] = id or false
  self:Refresh()
end

-- Rules shown and checked for a tab: the built-in rules plus the chosen extras
function ns:TabRules(spec)
  local list = {}
  local data = ns.RuleData[self.class]
  for _, r in ipairs(data and data[spec] or {}) do list[#list + 1] = r end
  for i = 1, ns.EXTRA_SLOTS do
    local r = self:GetExtras(spec)[i]
    if r then list[#list + 1] = r end
  end
  return list
end

function ns:SetCfg(spec, r, key, val)
  local t = self:RuleStore(spec, r, true)
  t[key] = val
  self:Refresh()
end

------------------------------------------------------------------------
-- Spec, spells, glyphs
------------------------------------------------------------------------
function ns:InBearForm()
  local bear1, bear2 = GetSpellInfo(5487), GetSpellInfo(9634)
  for i = 1, (GetNumShapeshiftForms() or 0) do
    local _, name, active = GetShapeshiftFormInfo(i)
    if active and (name == bear1 or name == bear2) then return true end
  end
  return false
end

-- Talent tab with the most points, or nil while the game hasn't loaded talent data
local function talentBest(group)
  local best, bp = nil, 0
  for i = 1, 3 do
    local _, _, pts = GetTalentTabInfo(i, false, false, group)
    pts = tonumber(pts) or 0
    if pts > bp then best, bp = i, pts end
  end
  return best
end

-- Last known spec per character and talent group (survives loading screens and relogs)
function ns:SpecStore()
  ProcBotDB.specs = ProcBotDB.specs or {}
  local t = ProcBotDB.specs[self.charKey]
  if not t then t = {}; ProcBotDB.specs[self.charKey] = t end
  return t
end

function ns:DetectSpec()
  local tabs = ns.SPECS[self.class]
  local spec, fromTalents = nil, false
  if tabs then
    local group = GetActiveTalentGroup and GetActiveTalentGroup() or 1
    local store = self:SpecStore()
    local idx = talentBest(group)
    if idx then
      store[group] = idx
      fromTalents = true
    else
      idx = store[group]
    end
    spec = idx and tabs[idx] or nil
    if self.class == "DRUID" and spec == "Feral" then
      spec = self:InBearForm() and "Feral (bear)" or "Feral (cat)"
    end
  end
  self.specFromTalents = fromTalents
  local changed = spec ~= self.spec
  self.spec = spec
  return changed
end

-- Manual choice from the spec picker or /pb spec 1-3
function ns:ChooseSpec(idx)
  local tabs = ns.SPECS[self.class]
  if not tabs or not tabs[idx] then return end
  local group = GetActiveTalentGroup and GetActiveTalentGroup() or 1
  self:SpecStore()[group] = idx
  self:DetectSpec()
  self:Refresh()
  self:Print(tostring(self.spec) .. " rules active")
end

-- After login, loading screens and spec swaps the talent data can arrive late:
-- keep checking for a while, then ask if the spec is still unknown.
local watch = CreateFrame("Frame")
watch:Hide()
watch:SetScript("OnUpdate", function(self, elapsed)
  self.t = self.t + elapsed
  self.acc = self.acc + elapsed
  if self.acc < 0.5 then return end
  self.acc = 0
  if ns:DetectSpec() then
    ns:Refresh()
    if ns.spec then ns:Print(ns.spec .. " rules active") end
  end
  if ns.specFromTalents then self:Hide(); return end
  if self.t > 10 then
    self:Hide()
    if not ns.spec and (UnitLevel("player") or 0) >= 10 and ns.SPECS[ns.class] then
      ns.Config:ShowSpecPicker()
    end
  end
end)

function ns:WatchSpec()
  watch.t, watch.acc = 0, 0.5
  watch:Show()
end

function ns:ScanKnown()
  local k = {}
  for tab = 1, GetNumSpellTabs() do
    local _, _, offset, num = GetSpellTabInfo(tab)
    for i = offset + 1, offset + num do
      local n = GetSpellName(i, BOOKTYPE_SPELL)
      if n then k[n] = true end
    end
  end
  self.known = k
end

function ns:ScanGlyphs()
  local g = {}
  local n = GetNumGlyphSockets and GetNumGlyphSockets() or 6
  for i = 1, n do
    local enabled, _, sid = GetGlyphSocketInfo(i)
    if enabled and sid then g[sid] = true end
  end
  self.glyphs = g
end

function ns:Refresh()
  if not self.ready then return end
  self.Engine:Build()
  self.Display:Layout()
  if self.Config then self.Config:RefreshIfShown() end
end

------------------------------------------------------------------------
-- Events
------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, e, ...)
  if ns[e] then ns[e](ns, ...) end
end)
ns.eventFrame = ev

function ns:ADDON_LOADED(name)
  if name ~= ADDON then return end
  ProcBotDB = ProcBotDB or {}
  ProcBotDB.profiles = ProcBotDB.profiles or {}
  ProcBotDB.chars = ProcBotDB.chars or {}
end

function ns:PLAYER_LOGIN()
  self.class = select(2, UnitClass("player"))
  self.charKey = UnitName("player") .. " - " .. GetRealmName()
  ns.defaults.layout.iconY = math.floor(UIParent:GetHeight() * 0.2 + 0.5)  -- 2/5 of center-to-top
  local pname = ProcBotDB.chars[self.charKey]
  if not pname or not ProcBotDB.profiles[pname] then pname = self.charKey end
  self:UseProfile(pname)
  self:CompileRules()
  self:ScanKnown()
  self:ScanGlyphs()
  self:DetectSpec()
  self.Display:Build()
  self.ready = true
  self:Refresh()
  self.Engine:Start()
  self.Config:BuildOptionsEntry()
  self:WatchSpec()

  for _, e in ipairs({"PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED", "CHARACTER_POINTS_CHANGED",
      "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "UPDATE_SHAPESHIFT_FORM", "GLYPH_ADDED", "GLYPH_REMOVED",
      "GLYPH_UPDATED", "PLAYER_ENTERING_WORLD"}) do
    ev:RegisterEvent(e)
  end
end

local function specEvent()
  if ns:DetectSpec() then
    ns:Refresh()
    if ns.spec then ns:Print((ns.spec) .. " rules active") end
  end
  if not ns.specFromTalents then ns:WatchSpec() end
end
ns.PLAYER_TALENT_UPDATE = specEvent
ns.ACTIVE_TALENT_GROUP_CHANGED = specEvent
ns.CHARACTER_POINTS_CHANGED = specEvent
ns.PLAYER_ENTERING_WORLD = function()
  ns:ScanKnown(); ns:ScanGlyphs(); ns:DetectSpec(); ns:Refresh()
  if not ns.specFromTalents then ns:WatchSpec() end
end
ns.UPDATE_SHAPESHIFT_FORM = function()
  if ns.class == "DRUID" and ns:DetectSpec() then ns:Refresh() end
end
ns.SPELLS_CHANGED = function() ns:ScanKnown() end
ns.LEARNED_SPELL_IN_TAB = ns.SPELLS_CHANGED
local function glyphEvent() ns:ScanGlyphs(); ns:Refresh() end
ns.GLYPH_ADDED = glyphEvent
ns.GLYPH_REMOVED = glyphEvent
ns.GLYPH_UPDATED = glyphEvent

------------------------------------------------------------------------
-- Slash commands
------------------------------------------------------------------------
local function slash(msg)
  msg = (msg or ""):lower():match("^%s*(.-)%s*$")
  if not ns.ready then return end
  if msg == "" or msg == "config" or msg == "options" then
    ns.Config:Toggle()
  elseif msg == "test" then
    ns.P.test = not ns.P.test
    ns:Print("test mode " .. (ns.P.test and "on" or "off"))
    ns:Refresh()
  elseif msg == "lock" then
    ns.P.locked = true; ns:Print("locked"); ns:Refresh()
  elseif msg == "unlock" then
    ns.P.locked = false; ns:Print("unlocked, drag the arcs or icons up and down"); ns:Refresh()
  elseif msg == "enable" or msg == "on" then
    ns:SetEnabled(true)
  elseif msg == "disable" or msg == "off" then
    ns:SetEnabled(false)
  elseif msg == "combat" then
    ns.P.combatOnly = not ns.P.combatOnly
    ns:Print(ns.P.combatOnly and "alerts only in combat" or "alerts in and out of combat")
    ns:Refresh()
  elseif msg:match("^spec%s+[123]$") then
    ns:ChooseSpec(tonumber(msg:match("[123]")))
  elseif msg == "spec pick" or msg == "pickspec" then
    ns.Config:ShowSpecPicker()
  elseif msg == "spec" then
    ns:Print("class " .. tostring(ns.class) .. ", spec " .. tostring(ns.spec or "none (no talent points)") ..
      ", profile " .. ns.profileName .. ", " .. #ns.active .. " rules active")
  elseif msg == "reset" then
    ns:ResetLayout(); ns:Print("layout reset (rules kept)")
  elseif msg == "export" then
    ns.Config:ShowExport("all")
  elseif msg == "import" then
    ns.Config:ShowImport()
  else
    ns:Print("/pb  open settings")
    ns:Print("/pb test  toggle test mode")
    ns:Print("/pb lock | unlock  lock or drag positions")
    ns:Print("/pb enable | disable  turn ProcBot on or off on all characters")
    ns:Print("/pb combat  toggle alerts only in combat")
    ns:Print("/pb spec  show detected spec")
    ns:Print("/pb spec 1 | 2 | 3  choose spec by talent tree, left to right")
    ns:Print("/pb spec pick  open the spec picker")
    ns:Print("/pb reset  reset layout")
    ns:Print("/pb export | import  profile strings")
  end
end

SLASH_PROCBOT1 = "/procbot"
SlashCmdList["PROCBOT"] = slash
-- Only take /pb if no other addon already owns it
local taken = false
for k, v in pairs(_G) do
  if type(k) == "string" and k:match("^SLASH_") and v == "/pb" then taken = true; break end
end
if not taken then SLASH_PROCBOT2 = "/pb" end

local ADDON, ns = ...
local E = {}
ns.Engine = E
ns.active = {}

local GetTime, UnitAura, UnitExists = GetTime, UnitAura, UnitExists
local min, floor = math.min, math.floor

-- aura caches, refreshed every tick
local pB, pBi, pD, pDi = {}, {}, {}, {}      -- player buffs / debuffs
local petB, petBi = {}, {}                  -- pet buffs
local tM, tMi, tA, tAi = {}, {}, {}, {}      -- target debuffs: mine / anyone's
local fM, fMi = {}, {}                      -- focus buffs: mine

local inCombat, hostileT, friendlyF = false, false, false

local function wipeT(t) for k in pairs(t) do t[k] = nil end end

local function scan(unit, filter, byN, byI, mine)
  wipeT(byN); wipeT(byI)
  if not UnitExists(unit) then return end
  for i = 1, 40 do
    local name, _, icon, count, _, _, expires, caster, _, _, sid = UnitAura(unit, i, filter)
    if not name then break end
    if not mine or caster == "player" or caster == "pet" or caster == "vehicle" then
      local e = byN[name]
      if not e then
        e = {count = count or 0, expires = expires or 0, icon = icon}
        byN[name] = e
      end
      if sid and not byI[sid] then byI[sid] = e end
    end
  end
end

local function find(set, byN, byI)
  if not set then return end
  for _, id in ipairs(set.ids) do
    local e = byI[id]
    if e then return e end
  end
  for _, n in ipairs(set.names) do
    local e = byN[n]
    if e then return e end
  end
end

local function remaining(e)
  if e.expires and e.expires > 0 then return e.expires - GetTime() end
  return 9999
end

local function known(name) return ns.known and ns.known[name] end

local function firstKnown(set)
  if not set then return end
  for _, n in ipairs(set.names) do
    if known(n) then return n end
  end
end

local function cdReady(name)
  local start, dur = GetSpellCooldown(name)
  if not start then return false end
  return start == 0 or dur <= 1.6
end

local function mana()
  local m = UnitPowerMax("player", 0)
  if not m or m == 0 then return 1 end
  return UnitPower("player", 0) / m
end

local function stacks(e) return (e.count and e.count > 0) and e.count or 1 end

------------------------------------------------------------------------
-- Weapon enchant text via tooltip
------------------------------------------------------------------------
local tip = CreateFrame("GameTooltip", "ProcBotScanTip", nil, "GameTooltipTemplate")
local wcache = {t = 0}

local function scanSlot(slot)
  tip:SetOwner(WorldFrame, "ANCHOR_NONE")
  tip:ClearLines()
  if not GetInventoryItemLink("player", slot) then return end
  tip:SetInventoryItem("player", slot)
  for i = 1, tip:NumLines() do
    local fs = _G["ProcBotScanTipTextLeft" .. i]
    local text = fs and fs:GetText()
    if text then
      local r, g, b = fs:GetTextColor()
      local name = text:match("^(.+) %(%d+ [^%)]+%)$")
      if name and g > 0.8 and r < 0.3 then return name end
    end
  end
end

local function enchantText(slot)
  local now = GetTime()
  if now - wcache.t > 1 then
    wcache[16] = scanSlot(16)
    wcache[17] = scanSlot(17)
    wcache.t = now
  end
  return wcache[slot]
end

local function offhandIsWeapon()
  local link = GetInventoryItemLink("player", 17)
  if not link then return false end
  local loc = select(9, GetItemInfo(link))
  return loc == "INVTYPE_WEAPON" or loc == "INVTYPE_WEAPONOFFHAND" or loc == "INVTYPE_2HWEAPON" or loc == "INVTYPE_WEAPONMAINHAND"
end

local function enchantMatches(slot, kw)
  if kw == "" then return true end
  local text = enchantText(slot)
  return text and text:lower():find(kw:lower(), 1, true)
end

------------------------------------------------------------------------
-- Rule evaluators: return active, level (0..1), pulse, icon, count
------------------------------------------------------------------------
local T = {}

T.buff = function(r, c, set)
  local byN, byI = pB, pBi
  if r.unit == "pet" then byN, byI = petB, petBi end
  local e = find(set, byN, byI)
  if not e then return end
  if r.mana_above and mana() < r.mana_above then return end
  local n = stacks(e)
  if r.max then return true, min(n, r.max) / r.max, false, e.icon, n end
  return true, 1, false, e.icon, n > 1 and n or nil
end

T.sdebuff = function(r, c, set)
  local e = find(set, pD, pDi)
  if not e then return end
  local n, m = stacks(e), r.max or 1
  return true, min(n, m) / m, false, e.icon, n
end

T.missing = function(r, c, set)
  if not r.nk and not firstKnown(set) then return end
  if r.combat and not inCombat then return end
  local e = find(set, pB, pBi)
  if e then
    local low = (r.below and remaining(e) < r.below) or (r.minCount and e.count and e.count > 0 and e.count < r.minCount)
    if not low then return end
    return true, 1, true, e.icon
  end
  return true, 1, true, set.icon
end

T.usable = function(r, c, set)
  local name = firstKnown(set)
  if not name then return end
  if not r.notarget and not hostileT then return end
  if r.needSet and not find(r.needSet, tM, tMi) then return end
  if not IsUsableSpell(name) then return end
  if not cdReady(name) then return end
  return true, 1, false, set.icon
end

T.cd = function(r, c, set)
  local name = firstKnown(set)
  if not name then return end
  if r.combat ~= false and not inCombat then return end
  if r.mana_below and mana() > r.mana_below then return end
  if r.needSet and not (hostileT and find(r.needSet, tM, tMi)) then return end
  if not cdReady(name) then return end
  return true, 1, false, set.icon
end

T.tdebuff = function(r, c, set)
  if not hostileT or not inCombat then return end
  if r.elite and UnitClassification("target") == "normal" then return end
  local byN, byI = tM, tMi
  if r.any then byN, byI = tA, tAi end
  if r.each then
    for _, sp in ipairs(set.list) do
      if r.nk or known(sp.name) then
        local e = byI[sp.id] or byN[sp.name]
        if not e or (r.below and remaining(e) < r.below) then return true, 1, false, sp.icon end
      end
    end
    return
  end
  if not r.nk and not firstKnown(set) then return end
  local e = find(set, byN, byI)
  if not e or (r.below and remaining(e) < r.below) then return true, 1, false, set.icon end
end

T.tstack = function(r, c, set)
  if not hostileT then return end
  local e = find(set, tM, tMi)
  if not e then return end
  local n, m = stacks(e), r.max or 1
  local pulse = r.below and remaining(e) < r.below
  return true, min(n, m) / m, pulse, e.icon, n
end

T.focus = function(r, c, set)
  if not friendlyF then return end
  if not r.nk and not firstKnown(set) then return end
  local e = find(set, fM, fMi)
  if e then
    local low = (r.below and remaining(e) < r.below) or (r.minCount and e.count and e.count > 0 and e.count < r.minCount)
    if not low then return end
  end
  return true, 1, true, set.icon
end

T.fstack = function(r, c, set)
  if not friendlyF then return end
  local e = find(set, fM, fMi)
  if not e then return end
  local n, m = stacks(e), r.max or 1
  local pulse = r.below and remaining(e) < r.below
  return true, min(n, m) / m, pulse, e.icon, n
end

T.pet = function(r, c, set)
  if not firstKnown(set) then return end
  if r.combat and not inCombat then return end
  if not UnitExists("pet") or UnitIsDead("pet") then return true, 1, true, set.icon end
  if r.happy and GetPetHappiness then
    local h = GetPetHappiness()
    if h and h < 3 then return true, 1, true, set.icon end
  end
end

T.weapon = function(r, c, set)
  local ch = r
  if r.choices then ch = r.choices[c.choice] or r.choices[1] end
  local hasMH, _, _, hasOH = GetWeaponEnchantInfo()
  if ch.mh and GetInventoryItemLink("player", 16) then
    if not hasMH or not enchantMatches(16, ch.mh) then return true, 1, true, set.icon end
  end
  if ch.oh and offhandIsWeapon() then
    if not hasOH or not enchantMatches(17, ch.oh) then return true, 1, true, set.icon end
  end
end

T.combo = function(r, c, set)
  local n = GetComboPoints("player", "target") or 0
  if n <= 0 then return end
  return true, min(n, 5) / 5, false, set.icon, n
end

T.lust = function(r, c, set)
  local name = firstKnown(set)
  if not name or not inCombat then return end
  if find(set, pB, pBi) then return end
  if find(r.satedSet, pD, pDi) then return end
  if not cdReady(name) then return end
  return true, 1, false, set.icon
end

T.totem = function(r, c, set)
  local name = firstKnown(set)
  if not name or not inCombat then return end
  local _, tname = GetTotemInfo(1)
  if tname and tname ~= "" and tname:find(name, 1, true) then return end
  return true, 1, true, set.icon
end

T.item = function(r, c, set)
  if inCombat or not firstKnown(set) then return end
  for _, id in ipairs(r.items or {}) do
    if (GetItemCount(id) or 0) > 0 then return end
  end
  return true, 1, true, set.icon
end

E.T = T

------------------------------------------------------------------------
-- Build the active rule list for the current class/spec
------------------------------------------------------------------------
function E:Build()
  local list = {}
  local data = ns.RuleData[ns.class]
  if data then
    local function add(spec, offset)
      for _, r in ipairs(ns:TabRules(spec)) do
        local c = ns:Cfg(spec, r)
        if c.on and (not r.glyph or (ns.glyphs and ns.glyphs[r.glyph])) and T[r.t] then
          list[#list + 1] = {r = r, c = c, p = c.prio + offset}
        end
      end
    end
    if ns.spec then add(ns.spec, 0) end
    add("All", 100000)
    table.sort(list, function(a, b) return a.p < b.p end)
  end
  ns.active = list
end

------------------------------------------------------------------------
-- Tick
------------------------------------------------------------------------
local arcsOut, iconsOut = {}, {}
local iconPool = {}

local function suppressed()
  if UnitIsDeadOrGhost("player") or UnitOnTaxi("player") then return true end
  if UnitInVehicle and UnitInVehicle("player") then return true end
  if IsMounted() and not UnitAffectingCombat("player") then return true end
  return false
end

function E:Tick()
  local P, D = ns.P, ns.Display
  if not ns:IsEnabled() then D:HideAll(); return end
  if P.test or not P.locked then D:ShowTest(); return end
  if suppressed() then D:HideAll(); return end
  if P.combatOnly and not UnitAffectingCombat("player") then D:HideAll(); return end

  inCombat = UnitAffectingCombat("player") and true or false
  hostileT = UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDead("target")
  friendlyF = UnitExists("focus") and UnitIsFriend("player", "focus") and not UnitIsDeadOrGhost("focus")

  scan("player", "HELPFUL", pB, pBi)
  scan("player", "HARMFUL", pD, pDi)
  scan("pet", "HELPFUL", petB, petBi)
  if hostileT then
    scan("target", "HARMFUL", tA, tAi)
    scan("target", "HARMFUL", tM, tMi, true)
  else
    wipeT(tA); wipeT(tAi); wipeT(tM); wipeT(tMi)
  end
  if friendlyF then scan("focus", "HELPFUL", fM, fMi, true) else wipeT(fM); wipeT(fMi) end

  for k in pairs(arcsOut) do arcsOut[k] = nil end
  for i = #iconsOut, 1, -1 do iconsOut[i] = nil end

  for _, a in ipairs(ns.active) do
    local r, c = a.r, a.c
    local slot = c.slot
    if slot == "I" and #iconsOut >= 4 then
      -- icon row full
    elseif slot ~= "I" and arcsOut[slot] then
      -- arc already taken by a higher priority rule
    else
      local set = r.set
      if r.choices and r.choices[c.choice] and r.choices[c.choice].set then set = r.choices[c.choice].set end
      local ok, lvl, pulse, icon, count = T[r.t](r, c, set)
      if ok and r.max and not c.glow and lvl < 1 then ok = false end
      if ok then
        pulse = pulse and P.layout.pulse
        if slot == "I" then
          local n = #iconsOut + 1
          local it = iconPool[n] or {}
          iconPool[n] = it
          it.icon, it.count, it.pulse = icon or set.icon, count, pulse
          iconsOut[n] = it
        else
          local st = arcsOut[slot] or {}
          st.level, st.pulse, st.color = lvl, pulse, c.color or r.col
          arcsOut[slot] = st
        end
      end
    end
  end
  D:Apply(arcsOut, iconsOut)
end

function E:Start()
  local f = CreateFrame("Frame")
  local acc = 0
  f:SetScript("OnUpdate", function(self, elapsed)
    ns.Display:Animate(elapsed)
    acc = acc + elapsed
    if acc < 0.1 then return end
    acc = 0
    E:Tick()
  end)
  self.frame = f
end

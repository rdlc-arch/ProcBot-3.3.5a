local ADDON, ns = ...
local D = {}
ns.Display = D

local TEX = "Interface\\AddOns\\ProcBot\\Textures\\"
local cos, sin, sqrt, pi, floor, max, min, abs = math.cos, math.sin, math.sqrt, math.pi, math.floor, math.max, math.min, math.abs

------------------------------------------------------------------------
-- Crescent arcs
--   Each arc is built from small textures placed along the curve:
--     glow   soft halo around the crescent            (full procs only)
--     body   the crescent: thick in the middle, pointed ends
--     core   bright line on the outer side of the body (full procs only)
--     inner  thin line just inside the crescent
--     rays   short streaks pointing outward           (full procs only)
--   Dot textures are white; the arc color is applied as vertex color.
------------------------------------------------------------------------
local LAYERS = {
  {key = "glow",  tex = "soft", blend = "ADD"},
  {key = "body",  tex = "disc", blend = "ADD", light = 0.1},
  {key = "inner", tex = "disc", blend = "ADD", light = 0.5},
  {key = "core",  tex = "disc", blend = "ADD", white = true},
  {key = "rays",  tex = "streak", blend = "ADD", light = 0.6},
}
local FULL_ONLY = {glow = true, core = true, rays = true}
local MAXDOTS = 160
local STREAK_REACH = 0.28   -- streak texture: ray runs from the center up to 28% of the texture size

local arcs, icons = {}, {}
local root, iconRoot, arcHandle, iconHandle
local clock = 0

------------------------------------------------------------------------
-- Geometry
--   Left/Right arcs lie on the iris circle (radius = side spacing).
--   Top/Bottom arcs (lids) lie on a wider ellipse: lid width x side spacing
--   horizontally, lid spacing vertically.
--   Arc lengths are fractions of the iris circumference, set separately for
--   the sides (sideFrac) and the lids (lidFrac), then multiplied by the
--   side/lid arc size together with the thickness.
------------------------------------------------------------------------
local function isSide(slot) return slot == "L" or slot == "R" end
D.IsSide = isSide

local function arcPolyline(slot, Lay)
  local r = Lay.spread
  local frac = isSide(slot) and Lay.sideFrac or Lay.lidFrac
  -- arc size scales the whole arc: its length as well as its thickness
  local L = 2 * pi * r / frac * (isSide(slot) and Lay.sideScale or Lay.lidScale)
  local pts, N = {}, 64
  if isSide(slot) then
    local mid = (slot == "L") and pi or 0
    local span = L / r
    for i = 0, N do
      local a = mid - span / 2 + span * i / N
      pts[#pts + 1] = {r * cos(a), r * sin(a)}
    end
  else
    local rx, ry = r * Lay.lidWidth, Lay.lidDist
    local half, acc, step = 0, 0, 0.0005
    local px, py = 0, ry
    while acc < L / 2 and half < pi / 2 do
      half = half + step
      local x, y = rx * cos(pi / 2 + half), ry * sin(pi / 2 + half)
      acc = acc + sqrt((x - px) ^ 2 + (y - py) ^ 2)
      px, py = x, y
    end
    local mid = (slot == "T") and (pi / 2) or (-pi / 2)
    for i = 0, N do
      local a = mid - half + 2 * half * i / N
      pts[#pts + 1] = {rx * cos(a), ry * sin(a)}
    end
  end
  return pts
end
D.ArcPolyline = arcPolyline

-- Evenly spaced points along the polyline with outward normal and position t (-1..1)
local function sample(pts, spacing, n)
  local cum, total = {0}, 0
  for i = 2, #pts do
    local dx, dy = pts[i][1] - pts[i - 1][1], pts[i][2] - pts[i - 1][2]
    total = total + sqrt(dx * dx + dy * dy)
    cum[i] = total
  end
  n = n or min(MAXDOTS, max(2, floor(total / spacing) + 1))
  local out, seg = {}, 2
  for i = 1, n do
    local d = (n > 1) and total * (i - 1) / (n - 1) or total / 2
    while seg < #pts and cum[seg] < d do seg = seg + 1 end
    local a, b = pts[seg - 1], pts[seg]
    local d0, d1 = cum[seg - 1], cum[seg]
    local f = (d1 > d0) and (d - d0) / (d1 - d0) or 0
    local x, y = a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f
    local tx, ty = b[1] - a[1], b[2] - a[2]
    local tl = sqrt(tx * tx + ty * ty)
    if tl == 0 then tl = 1 end
    local nx, ny = -ty / tl, tx / tl
    if nx * x + ny * y < 0 then nx, ny = -nx, -ny end
    out[i] = {x = x, y = y, nx = nx, ny = ny, t = (total > 0) and (2 * d / total - 1) or 0, len = total}
  end
  return out, total
end
D.Sample = sample

-- stable pseudo-random numbers so rays don't jump around between layouts
local function rnd(i, k)
  local v = sin(i * 12.9898 + k * 78.233) * 43758.5453
  return v - floor(v)
end

local function getTex(layer, i, spec)
  local t = layer.tex[i]
  if not t then
    t = layer:CreateTexture(nil, "ARTWORK")
    t:SetTexture(TEX .. spec.tex)
    t:SetBlendMode(spec.blend)
    if spec.white then t:SetVertexColor(1, 1, 1) end
    layer.tex[i] = t
  end
  return t
end

local function put(layer, i, spec, x, y, size, alpha)
  local t = getTex(layer, i, spec)
  t:SetWidth(size); t:SetHeight(size)
  t:ClearAllPoints()
  t:SetPoint("CENTER", layer, "CENTER", x, y)
  t:SetAlpha(alpha)
  t:Show()
end

-- per-dot alpha so overlapping dots add up to the target strength
local function addAlpha(target, size, spacing) return target / max(1, size / spacing) end
local function blendAlpha(target, size, spacing) return 1 - (1 - target) ^ (1 / max(1, size / spacing)) end

local function hideFrom(layer, n)
  for i = n, #layer.tex do layer.tex[i]:Hide() end
end

-- rotate a square texture so its "up" points along screen angle theta
local function rotateTex(t, theta)
  local phi = theta - pi / 2
  local c, s = cos(phi), sin(phi)
  local function uv(x, y)
    local xr = x * c + y * s
    local yr = -x * s + y * c
    return 0.5 + xr, 0.5 - yr
  end
  local ulx, uly = uv(-0.5, 0.5)
  local llx, lly = uv(-0.5, -0.5)
  local urx, ury = uv(0.5, 0.5)
  local lrx, lry = uv(0.5, -0.5)
  t:SetTexCoord(ulx, uly, llx, lly, urx, ury, lrx, lry)
end

local function buildArc(a, slot, L)
  local th = L.thick * (isSide(slot) and L.sideScale or L.lidScale)
  local pts = arcPolyline(slot, L)
  local ex = L.taper
  local function taper(t) return max(0, 1 - t * t) ^ ex end

  -- glow
  local sp = th * 0.6
  local s, n = sample(pts, sp), 0
  for _, p in ipairs(s) do
    local w = taper(p.t)
    if w > 0.05 then
      local off = th * 0.35 * w
      local size = th * 5.5 * w ^ 0.7 + 12
      n = n + 1
      put(a.layers.glow, n, LAYERS[1], p.x + p.nx * off, p.y + p.ny * off, size, addAlpha(2.4, size, sp))
    end
  end
  hideFrom(a.layers.glow, n + 1)

  -- crescent body (bulges slightly outward in the middle)
  sp = max(1, th * 0.14)
  s, n = sample(pts, sp), 0
  for _, p in ipairs(s) do
    local w = taper(p.t)
    if w > 0.02 then
      local off = th * 0.35 * w
      local size = max(2, th * 1.15 * w)
      n = n + 1
      put(a.layers.body, n, LAYERS[2], p.x + p.nx * off, p.y + p.ny * off, size, addAlpha(0.95, size, sp))
    end
  end
  hideFrom(a.layers.body, n + 1)

  -- bright core on the outer side of the crescent
  sp = max(1, th * 0.1)
  s, n = sample(pts, sp), 0
  for _, p in ipairs(s) do
    local w = taper(p.t)
    if w > 0.1 then
      local off = th * 0.35 * w + th * 0.3 * w
      local size = max(1.5, th * 0.3 * w ^ 1.2)
      n = n + 1
      put(a.layers.core, n, LAYERS[4], p.x + p.nx * off, p.y + p.ny * off, size, addAlpha(1.3, size, sp))
    end
  end
  hideFrom(a.layers.core, n + 1)

  -- thin inner line, a little shorter than the crescent
  s, n = sample(pts, 1.2), 0
  for _, p in ipairs(s) do
    local q = abs(p.t) / 0.92
    if q < 1 then
      local fade = (1 - q * q) ^ 1.2
      n = n + 1
      local size = max(1.5, th * 0.18)
      put(a.layers.inner, n, LAYERS[3], p.x - p.nx * th * 0.9, p.y - p.ny * th * 0.9, size, addAlpha(0.9, size, 1.2) * fade)
    end
  end
  hideFrom(a.layers.inner, n + 1)

  -- rays from the outer edge
  local count = floor(L.rayCount)
  a.rays = a.rays or {}
  local layer = a.layers.rays
  local seed = ({L = 1, R = 2, B = 3, T = 4})[slot]
  s = sample(pts, 1, 200)
  n = 0
  for i = 1, count do
    local t = -0.95 + 1.9 * rnd(seed * 100 + i, 1)
    local idx = floor((t + 1) / 2 * (#s - 1)) + 1
    local p = s[idx]
    local w = taper(p.t)
    if w > 0.05 then
      local off = th * 0.35 * w + th * 0.45 * w
      local len = th * L.rayLen * (0.35 + 0.65 * rnd(seed * 100 + i, 2)) * (0.4 + 0.6 * sqrt(w))
      local size = len / STREAK_REACH
      n = n + 1
      local tex = getTex(layer, n, LAYERS[5])
      tex:SetWidth(size); tex:SetHeight(size)
      tex:ClearAllPoints()
      tex:SetPoint("CENTER", layer, "CENTER", p.x + p.nx * off, p.y + p.ny * off)
      rotateTex(tex, math.atan2(p.ny, p.nx))
      local base = 0.45 + 0.55 * rnd(seed * 100 + i, 3)
      a.rays[n] = {tex = tex, base = base, spd = 1.2 + 2.2 * rnd(seed * 100 + i, 4), ph = 6.28 * rnd(seed * 100 + i, 5)}
      tex:SetAlpha(base)
      tex:Show()
    end
  end
  for i = n + 1, #a.rays do a.rays[i] = nil end
  hideFrom(layer, n + 1)
end

local function setArcColor(a, c)
  if a.cr == c[1] and a.cg == c[2] and a.cb == c[3] then return end
  a.cr, a.cg, a.cb = c[1], c[2], c[3]
  for _, spec in ipairs(LAYERS) do
    if not spec.white then
      local k = spec.light or 0
      local r, g, b = c[1] + (1 - c[1]) * k, c[2] + (1 - c[2]) * k, c[3] + (1 - c[3]) * k
      for _, t in ipairs(a.layers[spec.key].tex) do t:SetVertexColor(r, g, b) end
    end
  end
end

------------------------------------------------------------------------
-- Build frames
------------------------------------------------------------------------
local function makeHandle(label)
  local h = CreateFrame("Frame", nil, UIParent)
  h:SetFrameStrata("DIALOG")
  h:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12, insets = {left = 3, right = 3, top = 3, bottom = 3}})
  h:SetBackdropColor(0.1, 0.4, 0.8, 0.15)
  h:SetBackdropBorderColor(0.4, 0.7, 1, 0.8)
  local fs = h:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fs:SetPoint("TOP", h, "TOP", 0, -4)
  fs:SetText(label)
  h:EnableMouse(true)
  h:Hide()
  return h
end

local function makeDrag(h, key)
  h:SetScript("OnMouseDown", function(self)
    local _, y = GetCursorPosition()
    self.sy = y / UIParent:GetEffectiveScale()
    self.start = ns.P.layout[key]
    self:SetScript("OnUpdate", function(s)
      local _, cy = GetCursorPosition()
      cy = cy / UIParent:GetEffectiveScale()
      ns.P.layout[key] = floor(s.start + cy - s.sy + 0.5)
      D:Position()
    end)
  end)
  h:SetScript("OnMouseUp", function(self)
    self:SetScript("OnUpdate", nil)
    if ns.Config then ns.Config:RefreshIfShown() end
  end)
end

function D:Build()
  root = CreateFrame("Frame", "ProcBotArcs", UIParent)
  root:SetWidth(10); root:SetHeight(10)
  root:SetFrameStrata("LOW")
  for _, s in ipairs(ns.ARCS) do
    local a = CreateFrame("Frame", nil, root)
    a:SetAllPoints(root)
    a.layers = {}
    for _, spec in ipairs(LAYERS) do
      local l = CreateFrame("Frame", nil, a)
      l:SetAllPoints(a)
      l.tex = {}
      a.layers[spec.key] = l
    end
    a:Hide()
    arcs[s] = a
  end

  iconRoot = CreateFrame("Frame", "ProcBotIcons", UIParent)
  iconRoot:SetWidth(10); iconRoot:SetHeight(10)
  iconRoot:SetFrameStrata("LOW")
  for i = 1, 4 do
    local b = CreateFrame("Frame", nil, iconRoot)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", -2, 2); bg:SetPoint("BOTTOMRIGHT", 2, -2)
    bg:SetTexture(0, 0, 0, 0.8)
    local t = b:CreateTexture(nil, "ARTWORK")
    t:SetAllPoints(b)
    t:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local cnt = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalLarge")
    cnt:SetPoint("BOTTOMRIGHT", -2, 2)
    b.tex, b.count = t, cnt
    b:Hide()
    icons[i] = b
  end

  arcHandle = makeHandle("Arcs: drag up or down")
  iconHandle = makeHandle("Icons: drag up or down")
  makeDrag(arcHandle, "arcY")
  makeDrag(iconHandle, "iconY")
end

function D:Position()
  local L = ns.P.layout
  root:ClearAllPoints()
  -- overall scale: the whole arc group grows or shrinks around its center
  local g = L.scale or 1
  root:SetScale(g)
  root:SetPoint("CENTER", UIParent, "CENTER", 0, L.arcY / g)
  iconRoot:ClearAllPoints()
  iconRoot:SetPoint("CENTER", UIParent, "CENTER", 0, L.iconY)

  local w = 2 * L.spread * max(1, L.lidWidth) * 0.75 * g
  local h = 2 * L.lidDist + L.thick * L.lidScale * 3
  arcHandle:ClearAllPoints(); arcHandle:SetPoint("CENTER", root, "CENTER", 0, 0)
  arcHandle:SetWidth(w); arcHandle:SetHeight(h * g)
  iconHandle:ClearAllPoints(); iconHandle:SetPoint("CENTER", iconRoot, "CENTER", 0, 0)
  iconHandle:SetWidth(4 * L.iconSize + 3 * L.iconGap + 16); iconHandle:SetHeight(L.iconSize + 24)
  if ns.P.locked then arcHandle:Hide(); iconHandle:Hide() else arcHandle:Show(); iconHandle:Show() end
end

function D:Layout()
  if not root then return end
  local L = ns.P.layout
  for s, a in pairs(arcs) do
    buildArc(a, s, L)
    a.cr = nil
  end
  for _, b in ipairs(icons) do b:SetWidth(L.iconSize); b:SetHeight(L.iconSize) end
  self:Position()
end

------------------------------------------------------------------------
-- State
------------------------------------------------------------------------
local function showArc(s, level, pulse, color)
  local a = arcs[s]
  local P = ns.P
  local c = color or P.colors[s]
  setArcColor(a, c)
  local full = level >= 1
  for key in pairs(FULL_ONLY) do
    if full then a.layers[key]:Show() else a.layers[key]:Hide() end
  end
  a.full = full
  a.base = (0.3 + 0.7 * level) * (P.weight[s] or 1) * (c[4] or 1) * P.layout.alpha
  a.pulse = pulse
  a:Show()
end

local function hideIcons(from)
  for i = from, 4 do icons[i]:Hide() end
end

local function layoutIcons(n)
  local L = ns.P.layout
  local size, gap = L.iconSize, L.iconGap
  local total = n * size + (n - 1) * gap
  for i = 1, n do
    local b = icons[i]
    b:ClearAllPoints()
    b:SetPoint("CENTER", iconRoot, "CENTER", -total / 2 + size / 2 + (i - 1) * (size + gap), 0)
  end
end

function D:Apply(arcState, iconList)
  for _, s in ipairs(ns.ARCS) do
    local st = arcState[s]
    if st then showArc(s, st.level, st.pulse, st.color) else arcs[s]:Hide() end
  end
  local n = #iconList
  layoutIcons(n)
  for i = 1, n do
    local b, it = icons[i], iconList[i]
    b.tex:SetTexture(it.icon or ns.QUESTION)
    b.count:SetText((it.count and it.count > 1) and it.count or "")
    b.pulse = it.pulse
    b.base = ns.P.layout.alpha
    b:Show()
  end
  hideIcons(n + 1)
end

function D:ShowTest()
  for _, s in ipairs(ns.ARCS) do showArc(s, 1, false) end
  layoutIcons(4)
  for i = 1, 4 do
    local b = icons[i]
    b.tex:SetTexture(ns.QUESTION)
    b.count:SetText("")
    b.pulse = false
    b.base = ns.P.layout.alpha
    b:Show()
  end
end

function D:HideAll()
  for _, a in pairs(arcs) do a:Hide() end
  hideIcons(1)
end

function D:Animate(elapsed)
  clock = clock + elapsed
  local p = 0.55 + 0.45 * sin(clock * 5)
  local shimmer = ns.P and ns.P.layout.shimmer
  for _, a in pairs(arcs) do
    if a:IsShown() then
      a:SetAlpha((a.base or 1) * (a.pulse and p or 1))
      if a.full and a.rays then
        if shimmer then
          for _, r in ipairs(a.rays) do
            r.tex:SetAlpha(r.base * (0.35 + 0.65 * (0.5 + 0.5 * sin(clock * r.spd + r.ph))))
          end
          a.shimmering = true
        elseif a.shimmering then
          for _, r in ipairs(a.rays) do r.tex:SetAlpha(r.base) end
          a.shimmering = false
        end
      end
    end
  end
  for _, b in ipairs(icons) do
    if b:IsShown() then b:SetAlpha((b.base or 1) * (b.pulse and p or 1)) end
  end
end

local ADDON, ns = ...

-- Extra abilities you can add per tab with the 3 "Extra" pickers in the Rules tab.
-- Same fields as Rules.lua. Unlearned spells never fire, so every pool is safe on any spec.

ns.ExtraData = {
WARRIOR = {
  All = {
    {n="Berserker Rage ready", t="cd", s={"18499:Berserker Rage"}, slot="I"},
    {n="Bloodrage ready", t="cd", s={"2687:Bloodrage"}, slot="I"},
    {n="Recklessness ready", t="cd", s={"1719:Recklessness"}, slot="I"},
    {n="Enraged Regeneration ready", t="cd", s={"55694:Enraged Regeneration"}, slot="I"},
    {n="Shattering Throw ready", t="cd", s={"64382:Shattering Throw"}, slot="I"},
    {n="Heroic Throw ready", t="cd", s={"57755:Heroic Throw"}, slot="I"},
    {n="Sunder Armor on target", t="tdebuff", s={"7386:Sunder Armor"}, slot="I", any=true},
    {n="Hamstring on target", t="tdebuff", s={"1715:Hamstring"}, slot="I", any=true},
  },
  Arms = {
    {n="Mortal Strike ready", t="cd", s={"12294:Mortal Strike"}, slot="I"},
    {n="Bladestorm ready", t="cd", s={"46924:Bladestorm"}, slot="I"},
    {n="Sweeping Strikes ready", t="cd", s={"12328:Sweeping Strikes"}, slot="I"},
    {n="Taste for Blood", t="buff", s={"60503:Taste for Blood"}, slot="I"},
    {n="Juggernaut", t="buff", s={"65156:Juggernaut"}, slot="I"},
    {n="Trauma on target", t="tdebuff", s={"46857:Trauma"}, slot="I", any=true, nk=true},
  },
  Fury = {
    {n="Bloodthirst ready", t="cd", s={"23881:Bloodthirst"}, slot="I"},
    {n="Whirlwind ready", t="cd", s={"1680:Whirlwind"}, slot="I"},
    {n="Heroic Fury ready", t="cd", s={"60970:Heroic Fury"}, slot="I"},
    {n="Rampage missing", t="missing", s={"29801:Rampage"}, slot="I", combat=true},
    {n="Flurry", t="buff", s={"12970:Flurry"}, slot="I"},
  },
  Protection = {
    {n="Shield Slam ready", t="cd", s={"23922:Shield Slam"}, slot="I"},
    {n="Shockwave ready", t="cd", s={"46968:Shockwave"}, slot="I"},
    {n="Concussion Blow ready", t="cd", s={"12809:Concussion Blow"}, slot="I"},
    {n="Spell Reflection ready", t="cd", s={"23920:Spell Reflection"}, slot="I"},
    {n="Shield Wall ready", t="cd", s={"871:Shield Wall"}, slot="I"},
    {n="Last Stand ready", t="cd", s={"12975:Last Stand"}, slot="I"},
    {n="Vigilance on tank", t="focus", s={"50720:Vigilance"}, slot="I"},
  },
},

PALADIN = {
  All = {
    {n="Judgement ready", t="cd", s={"20271:Judgement of Light","53408:Judgement of Wisdom","53407:Judgement of Justice"}, slot="I"},
    {n="Avenging Wrath ready", t="cd", s={"31884:Avenging Wrath"}, slot="I"},
    {n="Divine Protection ready", t="cd", s={"498:Divine Protection"}, slot="I"},
    {n="Divine Shield ready", t="cd", s={"642:Divine Shield"}, slot="I"},
    {n="Lay on Hands ready", t="cd", s={"633:Lay on Hands"}, slot="I"},
    {n="Hand of Freedom ready", t="cd", s={"1044:Hand of Freedom"}, slot="I"},
    {n="Hammer of Justice ready", t="cd", s={"853:Hammer of Justice"}, slot="I"},
    {n="Judgement of Wisdom/Light on target", t="tdebuff", s={"20186:Judgement of Wisdom","20185:Judgement of Light"}, slot="I", any=true, nk=true},
  },
  Holy = {
    {n="Holy Shock ready", t="cd", s={"20473:Holy Shock"}, slot="I"},
    {n="Divine Illumination ready", t="cd", s={"31842:Divine Illumination"}, slot="I"},
    {n="Divine Favor ready", t="cd", s={"20216:Divine Favor"}, slot="I"},
    {n="Aura Mastery ready", t="cd", s={"31821:Aura Mastery"}, slot="I"},
    {n="Sacred Shield on self", t="missing", s={"53601:Sacred Shield"}, slot="I", combat=true},
  },
  Protection = {
    {n="Avenger's Shield ready", t="cd", s={"31935:Avenger's Shield"}, slot="I"},
    {n="Hammer of the Righteous ready", t="cd", s={"53595:Hammer of the Righteous"}, slot="I"},
    {n="Shield of Righteousness ready", t="cd", s={"53600:Shield of Righteousness"}, slot="I"},
    {n="Consecration ready", t="cd", s={"26573:Consecration"}, slot="I"},
    {n="Hand of Reckoning ready", t="cd", s={"62124:Hand of Reckoning"}, slot="I"},
    {n="Blessing of Sanctuary missing", t="missing", s={"20911:Blessing of Sanctuary","25899:Greater Blessing of Sanctuary"}, slot="I"},
  },
  Retribution = {
    {n="Crusader Strike ready", t="cd", s={"35395:Crusader Strike"}, slot="I"},
    {n="Divine Storm ready", t="cd", s={"53385:Divine Storm"}, slot="I"},
    {n="Consecration ready", t="cd", s={"26573:Consecration"}, slot="I"},
    {n="Exorcism ready", t="cd", s={"879:Exorcism"}, slot="I"},
    {n="Sacred Shield on self", t="missing", s={"53601:Sacred Shield"}, slot="I", combat=true},
  },
},

HUNTER = {
  All = {
    {n="Rapid Fire ready", t="cd", s={"3045:Rapid Fire"}, slot="I"},
    {n="Kill Command ready", t="cd", s={"34026:Kill Command"}, slot="I"},
    {n="Misdirection ready", t="cd", s={"34477:Misdirection"}, slot="I"},
    {n="Multi-Shot ready", t="cd", s={"2643:Multi-Shot"}, slot="I"},
    {n="Deterrence ready", t="cd", s={"19263:Deterrence"}, slot="I"},
    {n="Freezing Trap ready", t="cd", s={"1499:Freezing Trap"}, slot="I"},
  },
  ["Beast Mastery"] = {
    {n="Bestial Wrath ready", t="cd", s={"19574:Bestial Wrath"}, slot="I"},
    {n="Intimidation ready", t="cd", s={"19577:Intimidation"}, slot="I"},
    {n="Aimed Shot ready", t="cd", s={"19434:Aimed Shot"}, slot="I"},
    {n="Arcane Shot ready", t="cd", s={"3044:Arcane Shot"}, slot="I"},
  },
  Marksmanship = {
    {n="Aimed Shot ready", t="cd", s={"19434:Aimed Shot"}, slot="I"},
    {n="Readiness ready", t="cd", s={"23989:Readiness"}, slot="I"},
    {n="Silencing Shot ready", t="cd", s={"34490:Silencing Shot"}, slot="I"},
    {n="Rapid Killing", t="buff", s={"35098:Rapid Killing"}, slot="I"},
  },
  Survival = {
    {n="Explosive Shot ready", t="cd", s={"53301:Explosive Shot"}, slot="I"},
    {n="Black Arrow ready", t="cd", s={"3674:Black Arrow"}, slot="I"},
    {n="Wyvern Sting ready", t="cd", s={"19386:Wyvern Sting"}, slot="I"},
    {n="Sniper Training missing", t="missing", s={"53302:Sniper Training"}, slot="I", combat=true, nk=true},
    {n="Expose Weakness", t="buff", s={"34503:Expose Weakness"}, slot="I"},
  },
},

ROGUE = {
  All = {
    {n="Tricks of the Trade ready", t="cd", s={"57934:Tricks of the Trade"}, slot="I"},
    {n="Kick ready", t="cd", s={"1766:Kick"}, slot="I"},
    {n="Evasion ready", t="cd", s={"5277:Evasion"}, slot="I"},
    {n="Cloak of Shadows ready", t="cd", s={"31224:Cloak of Shadows"}, slot="I"},
    {n="Vanish ready", t="cd", s={"1856:Vanish"}, slot="I"},
    {n="Feint ready", t="cd", s={"1966:Feint"}, slot="I"},
    {n="Expose Armor on target", t="tdebuff", s={"8647:Expose Armor"}, slot="I", any=true},
  },
  Assassination = {
    {n="Overkill", t="buff", s={"58426:Overkill"}, slot="I"},
    {n="Deadly Poison x5 on target", t="tstack", s={"2818:Deadly Poison"}, slot="I", max=5, nk=true},
    {n="Turn the Tables", t="buff", s={"51627:Turn the Tables"}, slot="I"},
    {n="Garrote on target", t="tdebuff", s={"703:Garrote"}, slot="I"},
  },
  Combat = {
    {n="Riposte", t="usable", s={"14251:Riposte"}, slot="I"},
    {n="Sprint ready", t="cd", s={"2983:Sprint"}, slot="I"},
    {n="Killing Spree ready", t="cd", s={"51690:Killing Spree"}, slot="I"},
    {n="Adrenaline Rush ready", t="cd", s={"13750:Adrenaline Rush"}, slot="I"},
  },
  Subtlety = {
    {n="Shadow Dance ready", t="cd", s={"51713:Shadow Dance"}, slot="I"},
    {n="Shadowstep ready", t="cd", s={"36554:Shadowstep"}, slot="I"},
    {n="Preparation ready", t="cd", s={"14185:Preparation"}, slot="I"},
    {n="Master of Subtlety", t="buff", s={"31665:Master of Subtlety"}, slot="I"},
  },
},

PRIEST = {
  All = {
    {n="Shadowfiend ready", t="cd", s={"34433:Shadowfiend"}, slot="I"},
    {n="Hymn of Hope ready", t="cd", s={"64901:Hymn of Hope"}, slot="I"},
    {n="Psychic Scream ready", t="cd", s={"8122:Psychic Scream"}, slot="I"},
    {n="Fade ready", t="cd", s={"586:Fade"}, slot="I"},
    {n="Inner Focus ready", t="cd", s={"14751:Inner Focus"}, slot="I"},
    {n="Fear Ward on tank", t="focus", s={"6346:Fear Ward"}, slot="I"},
    {n="Prayer of Mending on tank", t="focus", s={"33076:Prayer of Mending"}, slot="I"},
  },
  Discipline = {
    {n="Penance ready", t="cd", s={"47540:Penance"}, slot="I"},
    {n="Pain Suppression ready", t="cd", s={"33206:Pain Suppression"}, slot="I"},
    {n="Power Word: Shield on tank", t="focus", s={"17:Power Word: Shield"}, slot="I"},
    {n="Renewed Hope", t="buff", s={"57472:Renewed Hope"}, slot="I"},
  },
  Holy = {
    {n="Guardian Spirit ready", t="cd", s={"47788:Guardian Spirit"}, slot="I"},
    {n="Circle of Healing ready", t="cd", s={"34861:Circle of Healing"}, slot="I"},
    {n="Prayer of Mending ready", t="cd", s={"33076:Prayer of Mending"}, slot="I"},
    {n="Divine Hymn ready", t="cd", s={"64843:Divine Hymn"}, slot="I"},
    {n="Desperate Prayer ready", t="cd", s={"19236:Desperate Prayer"}, slot="I"},
    {n="Renew on tank", t="focus", s={"139:Renew"}, slot="I"},
  },
  Shadow = {
    {n="Mind Blast ready", t="cd", s={"8092:Mind Blast"}, slot="I"},
    {n="Shadow Word: Death ready", t="cd", s={"32379:Shadow Word: Death"}, slot="I"},
    {n="Dispersion ready", t="cd", s={"47585:Dispersion"}, slot="I"},
    {n="Psychic Horror ready", t="cd", s={"64044:Psychic Horror"}, slot="I"},
    {n="Silence ready", t="cd", s={"15487:Silence"}, slot="I"},
  },
},

DEATHKNIGHT = {
  All = {
    {n="Icebound Fortitude ready", t="cd", s={"48792:Icebound Fortitude"}, slot="I"},
    {n="Anti-Magic Shell ready", t="cd", s={"48707:Anti-Magic Shell"}, slot="I"},
    {n="Mind Freeze ready", t="cd", s={"47528:Mind Freeze"}, slot="I"},
    {n="Strangulate ready", t="cd", s={"47476:Strangulate"}, slot="I"},
    {n="Death Grip ready", t="cd", s={"49576:Death Grip"}, slot="I"},
    {n="Empower Rune Weapon ready", t="cd", s={"47568:Empower Rune Weapon"}, slot="I"},
    {n="Blood Tap ready", t="cd", s={"45529:Blood Tap"}, slot="I"},
    {n="Army of the Dead ready", t="cd", s={"42650:Army of the Dead"}, slot="I"},
  },
  Blood = {
    {n="Dancing Rune Weapon ready", t="cd", s={"49028:Dancing Rune Weapon"}, slot="I"},
    {n="Mark of Blood ready", t="cd", s={"49005:Mark of Blood"}, slot="I"},
    {n="Hysteria ready", t="cd", s={"49016:Hysteria"}, slot="I"},
    {n="Blade Barrier missing", t="missing", s={"64859:Blade Barrier"}, slot="I", combat=true, nk=true},
  },
  Frost = {
    {n="Unbreakable Armor ready", t="cd", s={"51271:Unbreakable Armor"}, slot="I"},
    {n="Deathchill ready", t="cd", s={"49796:Deathchill"}, slot="I"},
    {n="Hungering Cold ready", t="cd", s={"49203:Hungering Cold"}, slot="I"},
    {n="Lichborne ready", t="cd", s={"49039:Lichborne"}, slot="I"},
    {n="Howling Blast ready", t="cd", s={"49184:Howling Blast"}, slot="I"},
  },
  Unholy = {
    {n="Anti-Magic Zone ready", t="cd", s={"51052:Anti-Magic Zone"}, slot="I"},
    {n="Ebon Plague on target", t="tdebuff", s={"51735:Ebon Plague"}, slot="I", any=true, nk=true},
    {n="Ghoul Frenzy ready", t="cd", s={"63560:Ghoul Frenzy"}, slot="I"},
    {n="Corpse Explosion ready", t="cd", s={"49158:Corpse Explosion"}, slot="I"},
  },
},

SHAMAN = {
  All = {
    {n="Wind Shear ready", t="cd", s={"57994:Wind Shear"}, slot="I"},
    {n="Fire Elemental Totem ready", t="cd", s={"2894:Fire Elemental Totem"}, slot="I"},
    {n="Earth Elemental Totem ready", t="cd", s={"2062:Earth Elemental Totem"}, slot="I"},
    {n="Grounding Totem ready", t="cd", s={"8177:Grounding Totem"}, slot="I"},
    {n="Hex ready", t="cd", s={"51514:Hex"}, slot="I"},
    {n="Earth Shock ready", t="cd", s={"8042:Earth Shock"}, slot="I"},
  },
  Elemental = {
    {n="Elemental Mastery ready", t="cd", s={"16166:Elemental Mastery"}, slot="I"},
    {n="Thunderstorm ready", t="cd", s={"51490:Thunderstorm"}, slot="I"},
    {n="Chain Lightning ready", t="cd", s={"421:Chain Lightning"}, slot="I"},
    {n="Elemental Oath", t="buff", s={"51466:Elemental Oath"}, slot="I"},
  },
  Enhancement = {
    {n="Stormstrike ready", t="cd", s={"17364:Stormstrike"}, slot="I"},
    {n="Lava Lash ready", t="cd", s={"60103:Lava Lash"}, slot="I"},
    {n="Fire Nova ready", t="cd", s={"1535:Fire Nova"}, slot="I"},
    {n="Flame Shock on target", t="tdebuff", s={"8050:Flame Shock"}, slot="I", below=2},
    {n="Stormstrike debuff on target", t="tdebuff", s={"17364:Stormstrike"}, slot="I"},
  },
  Restoration = {
    {n="Riptide ready", t="cd", s={"61295:Riptide"}, slot="I"},
    {n="Riptide on tank", t="focus", s={"61295:Riptide"}, slot="I"},
    {n="Mana Tide Totem ready", t="cd", s={"16190:Mana Tide Totem"}, slot="I"},
    {n="Tidal Force ready", t="cd", s={"55198:Tidal Force"}, slot="I"},
    {n="Chain Heal ready", t="cd", s={"1064:Chain Heal"}, slot="I"},
  },
},

MAGE = {
  All = {
    {n="Mirror Image ready", t="cd", s={"55342:Mirror Image"}, slot="I"},
    {n="Evocation ready", t="cd", s={"12051:Evocation"}, slot="I"},
    {n="Counterspell ready", t="cd", s={"2139:Counterspell"}, slot="I"},
    {n="Blink ready", t="cd", s={"1953:Blink"}, slot="I"},
    {n="Ice Block ready", t="cd", s={"45438:Ice Block"}, slot="I"},
    {n="Focus Magic on focus", t="focus", s={"54646:Focus Magic"}, slot="I"},
  },
  Arcane = {
    {n="Arcane Power ready", t="cd", s={"12042:Arcane Power"}, slot="I"},
    {n="Arcane Barrage ready", t="cd", s={"44425:Arcane Barrage"}, slot="I"},
    {n="Arcane Potency", t="buff", s={"57531:Arcane Potency"}, slot="I"},
    {n="Slow on target", t="tdebuff", s={"31589:Slow"}, slot="I"},
  },
  Fire = {
    {n="Fire Blast ready", t="cd", s={"2136:Fire Blast"}, slot="I"},
    {n="Dragon's Breath ready", t="cd", s={"31661:Dragon's Breath"}, slot="I"},
    {n="Blast Wave ready", t="cd", s={"11113:Blast Wave"}, slot="I"},
    {n="Ignite on target", t="tdebuff", s={"12654:Ignite"}, slot="I", nk=true},
  },
  Frost = {
    {n="Deep Freeze ready", t="cd", s={"44572:Deep Freeze"}, slot="I"},
    {n="Cold Snap ready", t="cd", s={"11958:Cold Snap"}, slot="I"},
    {n="Frost Nova ready", t="cd", s={"122:Frost Nova"}, slot="I"},
    {n="Summon Water Elemental ready", t="cd", s={"31687:Summon Water Elemental"}, slot="I"},
    {n="Ice Barrier missing", t="missing", s={"11426:Ice Barrier"}, slot="I", combat=true},
  },
},

WARLOCK = {
  All = {
    {n="Soulshatter ready", t="cd", s={"29858:Soulshatter"}, slot="I"},
    {n="Death Coil ready", t="cd", s={"6789:Death Coil"}, slot="I"},
    {n="Howl of Terror ready", t="cd", s={"5484:Howl of Terror"}, slot="I"},
    {n="Shadow Ward ready", t="cd", s={"6229:Shadow Ward"}, slot="I"},
    {n="Demonic Circle: Teleport ready", t="cd", s={"48020:Demonic Circle: Teleport"}, slot="I"},
    {n="Curse of the Elements on target", t="tdebuff", s={"1490:Curse of the Elements"}, slot="I", any=true},
    {n="Healthstone missing", t="item", s={"6201:Create Healthstone"}, items={36892,36893,36894,22103,22104,22105}, slot="I"},
  },
  Affliction = {
    {n="Haunt ready", t="cd", s={"48181:Haunt"}, slot="I"},
    {n="Shadow Embrace on target", t="tdebuff", s={"32385:Shadow Embrace"}, slot="I", nk=true},
    {n="Soul Link missing", t="missing", s={"19028:Soul Link"}, slot="I"},
    {n="Seed of Corruption ready", t="cd", s={"27243:Seed of Corruption"}, slot="I"},
  },
  Demonology = {
    {n="Soul Link missing", t="missing", s={"19028:Soul Link"}, slot="I"},
    {n="Immolate on target", t="tdebuff", s={"348:Immolate"}, slot="I", below=2},
    {n="Corruption on target", t="tdebuff", s={"172:Corruption"}, slot="I"},
    {n="Immolation Aura ready", t="cd", s={"50589:Immolation Aura"}, slot="I"},
  },
  Destruction = {
    {n="Chaos Bolt ready", t="cd", s={"50796:Chaos Bolt"}, slot="I"},
    {n="Shadowfury ready", t="cd", s={"30283:Shadowfury"}, slot="I"},
    {n="Shadowburn", t="usable", s={"17877:Shadowburn"}, slot="I"},
    {n="Pyroclasm", t="buff", s={"63244:Pyroclasm"}, slot="I"},
    {n="Curse of Doom ready", t="cd", s={"603:Curse of Doom"}, slot="I"},
  },
},

DRUID = {
  All = {
    {n="Innervate ready", t="cd", s={"29166:Innervate"}, slot="I"},
    {n="Barkskin ready", t="cd", s={"22812:Barkskin"}, slot="I"},
    {n="Rebirth ready", t="cd", s={"20484:Rebirth"}, slot="I"},
    {n="Tranquility ready", t="cd", s={"740:Tranquility"}, slot="I"},
    {n="Faerie Fire on target", t="tdebuff", s={"770:Faerie Fire","16857:Faerie Fire (Feral)"}, slot="I", any=true},
  },
  Balance = {
    {n="Force of Nature ready", t="cd", s={"33831:Force of Nature"}, slot="I"},
    {n="Typhoon ready", t="cd", s={"50516:Typhoon"}, slot="I"},
    {n="Nature's Grace", t="buff", s={"16886:Nature's Grace"}, slot="I"},
    {n="Elune's Wrath", t="buff", s={"64823:Elune's Wrath"}, slot="I"},
  },
  ["Feral (cat)"] = {
    {n="Berserk ready", t="cd", s={"50334:Berserk"}, slot="I"},
    {n="Faerie Fire (Feral) ready", t="cd", s={"16857:Faerie Fire (Feral)"}, slot="I"},
    {n="Dash ready", t="cd", s={"33357:Dash"}, slot="I"},
    {n="Feral Charge - Cat ready", t="cd", s={"49376:Feral Charge - Cat"}, slot="I"},
    {n="Survival Instincts ready", t="cd", s={"61336:Survival Instincts"}, slot="I"},
  },
  ["Feral (bear)"] = {
    {n="Mangle (Bear) ready", t="cd", s={"33878:Mangle (Bear)"}, slot="I"},
    {n="Berserk ready", t="cd", s={"50334:Berserk"}, slot="I"},
    {n="Enrage ready", t="cd", s={"5229:Enrage"}, slot="I"},
    {n="Faerie Fire (Feral) ready", t="cd", s={"16857:Faerie Fire (Feral)"}, slot="I"},
    {n="Bash ready", t="cd", s={"5211:Bash"}, slot="I"},
    {n="Growl ready", t="cd", s={"6795:Growl"}, slot="I"},
    {n="Challenging Roar ready", t="cd", s={"5209:Challenging Roar"}, slot="I"},
  },
  Restoration = {
    {n="Swiftmend ready", t="cd", s={"18562:Swiftmend"}, slot="I"},
    {n="Wild Growth ready", t="cd", s={"48438:Wild Growth"}, slot="I"},
    {n="Rejuvenation on tank", t="focus", s={"774:Rejuvenation"}, slot="I"},
    {n="Regrowth on tank", t="focus", s={"8936:Regrowth"}, slot="I"},
  },
},
}

ns.EXTRA_SLOTS = 3

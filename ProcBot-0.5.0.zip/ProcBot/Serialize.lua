local ADDON, ns = ...
local S = {}
ns.Serial = S

local floor, concat = math.floor, table.concat

------------------------------------------------------------------------
-- Table <-> string (no loadstring, so imported strings can't run code)
------------------------------------------------------------------------
local function ser(v, out, depth)
  if depth > 20 then return end
  local t = type(v)
  if t == "number" then
    out[#out + 1] = "n" .. tostring(v) .. ";"
  elseif t == "string" then
    out[#out + 1] = "s" .. #v .. ":" .. v
  elseif t == "boolean" then
    out[#out + 1] = v and "T" or "F"
  elseif t == "table" then
    out[#out + 1] = "{"
    for k, x in pairs(v) do
      local kt, xt = type(k), type(x)
      if (kt == "string" or kt == "number") and (xt == "string" or xt == "number" or xt == "boolean" or xt == "table") then
        ser(k, out, depth + 1)
        ser(x, out, depth + 1)
      end
    end
    out[#out + 1] = "}"
  end
end

function S.Serialize(v)
  local out = {}
  ser(v, out, 0)
  return concat(out)
end

local function parse(s, pos, depth)
  if depth > 20 then error("too deep") end
  local c = s:sub(pos, pos)
  if c == "n" then
    local e = s:find(";", pos, true)
    if not e then error("bad number") end
    local n = tonumber(s:sub(pos + 1, e - 1))
    if not n then error("bad number") end
    return n, e + 1
  elseif c == "s" then
    local e = s:find(":", pos, true)
    if not e then error("bad string") end
    local len = tonumber(s:sub(pos + 1, e - 1))
    if not len then error("bad string") end
    local str = s:sub(e + 1, e + len)
    if #str ~= len then error("bad string") end
    return str, e + len + 1
  elseif c == "T" then
    return true, pos + 1
  elseif c == "F" then
    return false, pos + 1
  elseif c == "{" then
    local t = {}
    pos = pos + 1
    while s:sub(pos, pos) ~= "}" do
      if pos > #s then error("unterminated table") end
      local k, v
      k, pos = parse(s, pos, depth + 1)
      v, pos = parse(s, pos, depth + 1)
      t[k] = v
    end
    return t, pos + 1
  end
  error("bad data")
end

function S.Deserialize(s)
  local ok, v, pos = pcall(parse, s, 1, 0)
  if not ok then return nil, v end
  return v
end

------------------------------------------------------------------------
-- Base64 + checksum
------------------------------------------------------------------------
local B = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local DEC = {}
for i = 1, 64 do DEC[B:sub(i, i)] = i - 1 end

function S.Encode(data)
  local out = {}
  for i = 1, #data, 3 do
    local a, b, c = data:byte(i, i + 2)
    local n = a * 65536 + (b or 0) * 256 + (c or 0)
    local c1, c2, c3, c4 = floor(n / 262144) % 64, floor(n / 4096) % 64, floor(n / 64) % 64, n % 64
    out[#out + 1] = B:sub(c1 + 1, c1 + 1) .. B:sub(c2 + 1, c2 + 1) ..
      (b and B:sub(c3 + 1, c3 + 1) or "=") .. (c and B:sub(c4 + 1, c4 + 1) or "=")
  end
  return concat(out)
end

function S.Decode(str)
  str = str:gsub("[^%w%+/=]", "")
  if #str % 4 ~= 0 then return nil end
  local out = {}
  for i = 1, #str, 4 do
    local q = str:sub(i, i + 3)
    local v = {}
    for j = 1, 4 do
      local ch = q:sub(j, j)
      if ch == "=" then v[j] = nil else
        v[j] = DEC[ch]
        if not v[j] then return nil end
      end
    end
    if not v[1] or not v[2] then return nil end
    local n = v[1] * 262144 + v[2] * 4096 + (v[3] or 0) * 64 + (v[4] or 0)
    local a, b, c = floor(n / 65536) % 256, floor(n / 256) % 256, n % 256
    out[#out + 1] = string.char(a)
    if v[3] then out[#out + 1] = string.char(b) end
    if v[4] then out[#out + 1] = string.char(c) end
  end
  return concat(out)
end

local function checksum(s)
  local a, b = 1, 0
  for i = 1, #s do
    a = (a + s:byte(i)) % 65521
    b = (b + a) % 65521
  end
  return string.format("%04x%04x", b, a)
end

local PREFIX = "PB1:"

function S.Pack(t)
  local raw = S.Serialize(t)
  return PREFIX .. S.Encode(raw) .. ":" .. checksum(raw)
end

function S.Unpack(str)
  str = (str or ""):gsub("%s", "")
  if str:sub(1, #PREFIX) ~= PREFIX then return nil, "Not a ProcBot string" end
  local body, sum = str:sub(#PREFIX + 1):match("^([^:]+):(%x+)$")
  if not body then return nil, "String is incomplete" end
  local raw = S.Decode(body)
  if not raw then return nil, "String is damaged" end
  if checksum(raw) ~= sum then return nil, "Checksum mismatch, the string was cut or changed" end
  local t, err = S.Deserialize(raw)
  if type(t) ~= "table" then return nil, "Could not read data" end
  return t
end

------------------------------------------------------------------------
-- Profile export / import
------------------------------------------------------------------------
function ns:Export(kind)
  local P = self.P
  local data
  if kind == "layout" then
    data = {layout = ns.Copy(P.layout), colors = ns.Copy(P.colors), weight = ns.Copy(P.weight)}
  elseif kind == "rules" then
    data = {class = self.class, rules = ns.Copy(P.rules[self.class] or {})}
  else
    kind = "all"
    data = ns.Copy(P)
  end
  return S.Pack({v = 1, kind = kind, name = self.profileName, class = self.class, version = ns.version, data = data})
end

function ns:ReadImport(str)
  local t, err = S.Unpack(str)
  if not t then return nil, err end
  if type(t.data) ~= "table" or (t.kind ~= "all" and t.kind ~= "layout" and t.kind ~= "rules") then
    return nil, "Unknown ProcBot string"
  end
  return t
end

function ns:DescribeImport(t)
  if t.kind == "all" then
    return "Full profile \"" .. tostring(t.name) .. "\" (layout, colors and rules)"
  elseif t.kind == "layout" then
    return "Layout and colors from \"" .. tostring(t.name) .. "\""
  else
    return "Rules for " .. tostring(t.data.class) .. " from \"" .. tostring(t.name) .. "\""
  end
end

function ns:ApplyImport(t, asNew)
  local name = self.profileName
  if asNew then
    name = self:UniqueName(type(t.name) == "string" and t.name or "Imported")
    ProcBotDB.profiles[name] = ns.Copy(self.P)
  end
  local target = ProcBotDB.profiles[name]
  if t.kind == "all" then
    for k in pairs(target) do target[k] = nil end
    for k, v in pairs(ns.Copy(t.data)) do target[k] = v end
  elseif t.kind == "layout" then
    if type(t.data.layout) == "table" then target.layout = ns.Copy(t.data.layout) end
    if type(t.data.colors) == "table" then target.colors = ns.Copy(t.data.colors) end
    if type(t.data.weight) == "table" then target.weight = ns.Copy(t.data.weight) end
  elseif t.kind == "rules" and type(t.data.class) == "string" and type(t.data.rules) == "table" then
    target.rules = target.rules or {}
    target.rules[t.data.class] = ns.Copy(t.data.rules)
  end
  self:SetProfile(name)
  return name
end

local ADDON, ns = ...

-- Rule fields
--   n      label shown in the config
--   t      type: buff, sdebuff, missing, usable, cd, tdebuff, tstack, focus, fstack,
--          pet, weapon, combo, lust, totem, item
--   s      spells as "id:English name" (English name is used on enUS/enGB clients,
--          the id resolves the localized name on other clients)
--   slot   default placement: L, R, B, T (arcs) or I (icon pop-up)
--   off    true = disabled by default
--   max    stacks for build-up glow
--   below  warn when remaining time is under this many seconds
--   minCount  warn when charges/stacks are under this number
--   combat only while in combat
--   nk     skip the "spell is known" check (talent procs that are not in the spellbook)
--   any    target debuff from any caster counts
--   each   warn for each listed debuff separately
--   needT  your debuff that must be on the target
--   choices alternatives selectable in the config

local SEALS = {"21084:Seal of Righteousness","20375:Seal of Command","20165:Seal of Light","20166:Seal of Wisdom",
  "20164:Seal of Justice","31801:Seal of Vengeance","53736:Seal of Corruption","31892:Seal of Blood","53720:Seal of the Martyr"}
local AURAS = {"465:Devotion Aura","7294:Retribution Aura","19746:Concentration Aura","19876:Shadow Resistance Aura",
  "19888:Frost Resistance Aura","19891:Fire Resistance Aura","32223:Crusader Aura"}
local BLESSINGS = {"19740:Blessing of Might","25782:Greater Blessing of Might","20217:Blessing of Kings","25898:Greater Blessing of Kings",
  "19742:Blessing of Wisdom","25894:Greater Blessing of Wisdom","20911:Blessing of Sanctuary","25899:Greater Blessing of Sanctuary"}
local PRESENCES = {
  {label="Blood Presence", s={"48266:Blood Presence"}},
  {label="Frost Presence", s={"48263:Frost Presence"}},
  {label="Unholy Presence", s={"48265:Unholy Presence"}},
}

ns.RuleData = {
WARRIOR = {
  All = {
    {n="Battle / Commanding Shout", t="missing", s={"6673:Battle Shout","469:Commanding Shout"}, slot="I"},
  },
  Arms = {
    {n="Sudden Death", t="buff", s={"52437:Sudden Death"}, slot="L"},
    {n="Overpower", t="usable", s={"7384:Overpower"}, slot="R"},
    {n="Execute", t="usable", s={"5308:Execute"}, slot="T"},
    {n="Rend on target", t="tdebuff", s={"772:Rend"}, slot="I", off=true, below=3},
    {n="Victory Rush", t="usable", s={"34428:Victory Rush"}, slot="I", off=true},
  },
  Fury = {
    {n="Bloodsurge (Slam!)", t="buff", s={"46916:Slam!"}, slot="L"},
    {n="Execute", t="usable", s={"5308:Execute"}, slot="T"},
    {n="Death Wish / Enrage active", t="buff", s={"12292:Death Wish","12880:Enrage"}, slot="I", off=true},
    {n="Victory Rush", t="usable", s={"34428:Victory Rush"}, slot="I", off=true},
  },
  Protection = {
    {n="Sword and Board", t="buff", s={"50227:Sword and Board"}, slot="L"},
    {n="Revenge", t="usable", s={"6572:Revenge"}, slot="R"},
    {n="Free Heroic Strike (Glyph of Revenge)", t="buff", s={"58363:Glyph of Revenge"}, slot="I", off=true},
    {n="Thunder Clap on target", t="tdebuff", s={"6343:Thunder Clap"}, slot="I", off=true, any=true},
    {n="Demoralizing Shout on target", t="tdebuff", s={"1160:Demoralizing Shout","99:Demoralizing Roar"}, slot="I", off=true, any=true},
    {n="Shield Block ready", t="cd", s={"2565:Shield Block"}, slot="I", off=true},
  },
},

PALADIN = {
  All = {
    {n="Seal missing", t="missing", s=SEALS, slot="R"},
    {n="Aura missing", t="missing", s=AURAS, slot="I"},
    {n="Blessing on self missing", t="missing", s=BLESSINGS, slot="I"},
    {n="Divine Plea", t="cd", s={"54428:Divine Plea"}, slot="I", off=true, mana_below=0.8},
  },
  Holy = {
    {n="Infusion of Light", t="buff", s={"54149:Infusion of Light"}, slot="L"},
    {n="Beacon of Light on tank", t="focus", s={"53563:Beacon of Light"}, slot="B", below=5},
    {n="Sacred Shield on tank", t="focus", s={"53601:Sacred Shield"}, slot="I", off=true},
    {n="Light's Grace", t="missing", s={"31834:Light's Grace"}, slot="I", off=true, combat=true, nk=true},
    {n="Judgements of the Pure", t="missing", s={"53657:Judgements of the Pure"}, slot="I", off=true, combat=true, nk=true},
  },
  Protection = {
    {n="Righteous Fury", t="missing", s={"25780:Righteous Fury"}, slot="T"},
    {n="Holy Shield", t="missing", s={"20925:Holy Shield"}, slot="B", combat=true, below=2},
    {n="Sacred Shield on self", t="missing", s={"53601:Sacred Shield"}, slot="I", off=true, combat=true},
  },
  Retribution = {
    {n="The Art of War", t="buff", s={"59578:The Art of War"}, slot="L"},
    {n="Hammer of Wrath", t="usable", s={"24275:Hammer of Wrath"}, slot="T"},
    {n="Avenging Wrath active", t="buff", s={"31884:Avenging Wrath"}, slot="I", off=true},
  },
},

HUNTER = {
  All = {
    {n="Aspect missing", t="missing", s={"61846:Aspect of the Dragonhawk","13165:Aspect of the Hawk","34074:Aspect of the Viper","13163:Aspect of the Monkey"}, slot="R"},
    {n="Aspect of the Viper at high mana", t="buff", s={"34074:Aspect of the Viper"}, slot="R", mana_above=0.9},
    {n="Kill Shot", t="usable", s={"53351:Kill Shot"}, slot="T"},
    {n="Pet missing / dead / unhappy", t="pet", s={"883:Call Pet"}, slot="B", happy=true},
    {n="Hunter's Mark on target", t="tdebuff", s={"1130:Hunter's Mark"}, slot="I", any=true, elite=true},
    {n="Serpent Sting on target", t="tdebuff", s={"1978:Serpent Sting"}, slot="I", off=true, below=2},
  },
  ["Beast Mastery"] = {
    {n="Cobra Strikes", t="buff", s={"53257:Cobra Strikes"}, slot="L", unit="pet"},
    {n="Bestial Wrath / The Beast Within", t="buff", s={"34471:The Beast Within","19574:Bestial Wrath"}, slot="I", off=true},
  },
  Marksmanship = {
    {n="Improved Steady Shot", t="buff", s={"53220:Improved Steady Shot"}, slot="L"},
    {n="Trueshot Aura", t="missing", s={"19506:Trueshot Aura"}, slot="I"},
    {n="Chimera Shot ready", t="cd", s={"53209:Chimera Shot"}, slot="I", off=true},
  },
  Survival = {
    {n="Lock and Load", t="buff", s={"56453:Lock and Load"}, slot="L"},
    {n="Black Arrow on target", t="tdebuff", s={"3674:Black Arrow"}, slot="I", off=true},
  },
},

ROGUE = {
  All = {
    {n="Combo points 5", t="combo", s={"2098:Eviscerate"}, slot="L", max=5},
    {n="Slice and Dice", t="missing", s={"5171:Slice and Dice"}, slot="R", combat=true, below=3},
    {n="Main-hand poison", t="weapon", s={"8679:Instant Poison"}, slot="B", mh="Poison"},
    {n="Off-hand poison", t="weapon", s={"2823:Deadly Poison"}, slot="B", oh="Poison"},
  },
  Assassination = {
    {n="Hunger for Blood", t="missing", s={"51662:Hunger for Blood"}, slot="T", combat=true, below=5},
    {n="Envenom buff", t="missing", s={"32645:Envenom"}, slot="I", off=true, combat=true},
    {n="Rupture on target", t="tdebuff", s={"1943:Rupture"}, slot="I", off=true},
    {n="Cold Blood ready", t="cd", s={"14177:Cold Blood"}, slot="I", off=true},
  },
  Combat = {
    {n="Adrenaline Rush / Killing Spree ready", t="cd", s={"13750:Adrenaline Rush","51690:Killing Spree"}, slot="T", off=true},
    {n="Blade Flurry ready", t="cd", s={"13877:Blade Flurry"}, slot="I", off=true},
    {n="Rupture on target", t="tdebuff", s={"1943:Rupture"}, slot="I", off=true},
  },
  Subtlety = {
    {n="Shadow Dance active", t="buff", s={"51713:Shadow Dance"}, slot="T"},
    {n="Hemorrhage debuff on target", t="tdebuff", s={"16511:Hemorrhage"}, slot="I", off=true, any=true},
    {n="Premeditation ready", t="usable", s={"14183:Premeditation"}, slot="I", off=true},
  },
},

PRIEST = {
  All = {
    {n="Inner Fire", t="missing", s={"588:Inner Fire"}, slot="R", minCount=5},
    {n="Power Word: Fortitude", t="missing", s={"1243:Power Word: Fortitude","21562:Prayer of Fortitude"}, slot="I"},
    {n="Divine Spirit", t="missing", s={"14752:Divine Spirit","27681:Prayer of Spirit"}, slot="I", off=true},
    {n="Shadow Protection", t="missing", s={"976:Shadow Protection","27683:Prayer of Shadow Protection"}, slot="I", off=true},
  },
  Discipline = {
    {n="Borrowed Time", t="buff", s={"59891:Borrowed Time"}, slot="L"},
    {n="Grace on tank", t="focus", s={"47930:Grace"}, slot="I", off=true, minCount=3, nk=true},
    {n="Power Infusion ready", t="cd", s={"10060:Power Infusion"}, slot="T", off=true},
  },
  Holy = {
    {n="Surge of Light", t="buff", s={"33151:Surge of Light"}, slot="L"},
    {n="Serendipity x3", t="buff", s={"63735:Serendipity"}, slot="B", max=3},
    {n="Holy Concentration", t="buff", s={"34754:Holy Concentration"}, slot="T", off=true},
  },
  Shadow = {
    {n="Shadowform", t="missing", s={"15473:Shadowform"}, slot="T"},
    {n="Shadow Weaving x5", t="buff", s={"15258:Shadow Weaving"}, slot="L", max=5},
    {n="Vampiric Embrace", t="missing", s={"15286:Vampiric Embrace"}, slot="B"},
    {n="VT / SW:P / Devouring Plague on target", t="tdebuff", s={"34914:Vampiric Touch","589:Shadow Word: Pain","2944:Devouring Plague"}, slot="I", off=true, each=true, below=2},
    {n="Improved Spirit Tap", t="buff", s={"59000:Improved Spirit Tap"}, slot="I", off=true},
  },
},

DEATHKNIGHT = {
  All = {
    {n="Horn of Winter", t="missing", s={"57330:Horn of Winter"}, slot="I", below=10},
    {n="Diseases on target", t="tdebuff", s={"55095:Frost Fever","55078:Blood Plague"}, slot="B", each=true, below=3, nk=true},
  },
  Blood = {
    {n="Presence (tank: Frost)", t="missing", choices=PRESENCES, choice=2, slot="R"},
    {n="Rune Strike", t="usable", s={"56815:Rune Strike"}, slot="L"},
    {n="Vampiric Blood / Rune Tap ready", t="cd", s={"55233:Vampiric Blood","48982:Rune Tap"}, slot="I", off=true},
  },
  Frost = {
    {n="Presence (DPS: Blood)", t="missing", choices=PRESENCES, choice=1, slot="R"},
    {n="Rime (Freezing Fog)", t="buff", s={"59052:Freezing Fog"}, slot="L"},
    {n="Killing Machine", t="buff", s={"51124:Killing Machine"}, slot="T"},
    {n="Rune Strike (if tanking)", t="usable", s={"56815:Rune Strike"}, slot="I", off=true},
  },
  Unholy = {
    {n="Presence (DPS: Blood)", t="missing", choices=PRESENCES, choice=1, slot="R"},
    {n="Bone Shield", t="missing", s={"49222:Bone Shield"}, slot="T", minCount=2},
    {n="Ghoul missing", t="pet", s={"46584:Raise Dead"}, slot="I"},
    {n="Desolation", t="missing", s={"66803:Desolation"}, slot="L", off=true, combat=true, nk=true},
    {n="Summon Gargoyle ready", t="cd", s={"49206:Summon Gargoyle"}, slot="I", off=true},
  },
},

SHAMAN = {
  All = {
    {n="Heroism / Bloodlust available", t="lust", s={"32182:Heroism","2825:Bloodlust"}, sated={"57724:Sated","57723:Exhaustion"}, slot="T"},
  },
  Elemental = {
    {n="Lava Burst + Flame Shock up", t="usable", s={"51505:Lava Burst"}, needT={"8050:Flame Shock"}, slot="L"},
    {n="Shield", t="missing", choices={{label="Water Shield", s={"52127:Water Shield"}},{label="Lightning Shield", s={"324:Lightning Shield"}}}, choice=1, slot="R"},
    {n="Flametongue Weapon", t="weapon", s={"8024:Flametongue Weapon"}, slot="B", mh="Flametongue"},
    {n="Clearcasting (Elemental Focus)", t="buff", s={"16246:Clearcasting"}, slot="I", off=true},
    {n="Flame Shock on target", t="tdebuff", s={"8050:Flame Shock"}, slot="I", off=true, below=2},
    {n="Totem of Wrath missing", t="totem", s={"30706:Totem of Wrath"}, slot="I", off=true},
  },
  Enhancement = {
    {n="Maelstrom Weapon x5", t="buff", s={"53817:Maelstrom Weapon"}, slot="L", max=5},
    {n="Lightning Shield", t="missing", s={"324:Lightning Shield"}, slot="R"},
    {n="Weapon imbues", t="weapon", s={"8232:Windfury Weapon"}, slot="B", choices={
      {label="Windfury + Flametongue", mh="Windfury", oh="Flametongue"},
      {label="Windfury + Windfury", mh="Windfury", oh="Windfury"},
      {label="Any imbue", mh="", oh=""}}, choice=1},
    {n="Shamanistic Rage ready", t="cd", s={"30823:Shamanistic Rage"}, slot="I", off=true},
    {n="Feral Spirit ready", t="cd", s={"51533:Feral Spirit"}, slot="I", off=true},
  },
  Restoration = {
    {n="Tidal Waves", t="buff", s={"53390:Tidal Waves"}, slot="L"},
    {n="Water Shield", t="missing", s={"52127:Water Shield"}, slot="R"},
    {n="Earthliving Weapon", t="weapon", s={"51730:Earthliving Weapon"}, slot="B", mh="Earthliving"},
    {n="Earth Shield on tank", t="focus", s={"974:Earth Shield"}, slot="I", minCount=3},
    {n="Nature's Swiftness ready", t="cd", s={"16188:Nature's Swiftness"}, slot="I", off=true},
  },
},

MAGE = {
  All = {
    {n="Armor missing", t="missing", s={"30482:Molten Armor","6117:Mage Armor","7302:Ice Armor","168:Frost Armor"}, slot="R"},
    {n="Arcane Intellect", t="missing", s={"1459:Arcane Intellect","23028:Arcane Brilliance","61024:Dalaran Intellect","61316:Dalaran Brilliance"}, slot="I"},
    {n="Mana gem missing", t="item", s={"759:Conjure Mana Gem"}, items={33312,22044,8008,8007,5513,5514}, slot="I", off=true},
  },
  Arcane = {
    {n="Missile Barrage", t="buff", s={"44401:Missile Barrage"}, slot="L"},
    {n="Arcane Blast stacks x4", t="sdebuff", s={"36032:Arcane Blast"}, slot="T", max=4},
    {n="Clearcasting", t="buff", s={"12536:Clearcasting"}, slot="B"},
    {n="Presence of Mind ready", t="cd", s={"12043:Presence of Mind"}, slot="I", off=true},
  },
  Fire = {
    {n="Hot Streak", t="buff", s={"48108:Hot Streak"}, slot="L"},
    {n="Firestarter", t="buff", s={"54741:Firestarter"}, slot="B"},
    {n="Living Bomb on target", t="tdebuff", s={"44457:Living Bomb"}, slot="I", off=true},
    {n="Improved Scorch debuff", t="tdebuff", s={"22959:Improved Scorch"}, slot="I", off=true, any=true, below=5, nk=true},
    {n="Combustion ready", t="cd", s={"11129:Combustion"}, slot="I", off=true},
  },
  Frost = {
    {n="Brain Freeze (Fireball!)", t="buff", s={"57761:Fireball!"}, slot="L"},
    {n="Fingers of Frost", t="buff", s={"44544:Fingers of Frost"}, slot="T"},
    {n="Water Elemental missing", t="pet", s={"31687:Summon Water Elemental"}, slot="I", combat=true},
    {n="Icy Veins ready", t="cd", s={"12472:Icy Veins"}, slot="I", off=true},
  },
},

WARLOCK = {
  All = {
    {n="Fel Armor missing", t="missing", s={"28176:Fel Armor","706:Demon Armor","687:Demon Skin"}, slot="R"},
    {n="Weapon stone", t="weapon", s={"2362:Create Spellstone"}, slot="B", mh="stone"},
    {n="Life Tap glyph buff", t="missing", s={"63321:Life Tap"}, slot="I", combat=true, nk=true, glyph=63320},
    {n="Pet missing", t="pet", s={"688:Summon Imp"}, slot="I"},
  },
  Affliction = {
    {n="Nightfall (Shadow Trance)", t="buff", s={"17941:Shadow Trance"}, slot="L"},
    {n="Eradication", t="buff", s={"64371:Eradication"}, slot="T", off=true},
    {n="Haunt / UA / Corruption / Curse on target", t="tdebuff", s={"48181:Haunt","30108:Unstable Affliction","172:Corruption","980:Curse of Agony"}, slot="I", off=true, each=true, below=2},
  },
  Demonology = {
    {n="Decimation", t="buff", s={"63167:Decimation"}, slot="L"},
    {n="Molten Core", t="buff", s={"71165:Molten Core"}, slot="T"},
    {n="Metamorphosis ready", t="cd", s={"47241:Metamorphosis"}, slot="I", off=true},
    {n="Demonic Empowerment ready", t="cd", s={"47193:Demonic Empowerment"}, slot="I", off=true},
  },
  Destruction = {
    {n="Backlash", t="buff", s={"34936:Backlash"}, slot="L"},
    {n="Empowered Imp", t="buff", s={"47283:Empowered Imp"}, slot="T"},
    {n="Backdraft", t="buff", s={"54277:Backdraft"}, slot="I", off=true},
    {n="Immolate on target", t="tdebuff", s={"348:Immolate"}, slot="I", off=true, below=2},
    {n="Conflagrate ready", t="cd", s={"17962:Conflagrate"}, needT={"348:Immolate"}, slot="I", off=true},
  },
},

DRUID = {
  All = {
    {n="Mark of the Wild", t="missing", s={"1126:Mark of the Wild","21849:Gift of the Wild"}, slot="I"},
    {n="Thorns", t="missing", s={"467:Thorns"}, slot="I", off=true},
    {n="Clearcasting (Omen of Clarity)", t="buff", s={"16870:Clearcasting"}, slot="B"},
  },
  Balance = {
    {n="Solar Eclipse", t="buff", s={"48517:Eclipse (Solar)"}, slot="L", col={1,0.55,0.15,1}},
    {n="Lunar Eclipse", t="buff", s={"48518:Eclipse (Lunar)"}, slot="R", col={0.35,0.6,1,1}},
    {n="Moonkin Form missing", t="missing", s={"24858:Moonkin Form"}, slot="T"},
    {n="Owlkin Frenzy", t="buff", s={"48391:Owlkin Frenzy"}, slot="I", off=true},
    {n="Insect Swarm / Moonfire on target", t="tdebuff", s={"5570:Insect Swarm","8921:Moonfire"}, slot="I", off=true, each=true, below=2},
    {n="Faerie Fire on target", t="tdebuff", s={"770:Faerie Fire"}, slot="I", off=true, any=true},
    {n="Starfall ready", t="cd", s={"48505:Starfall"}, slot="I", off=true},
  },
  ["Feral (cat)"] = {
    {n="Combo points 5", t="combo", s={"22568:Ferocious Bite"}, slot="L", max=5},
    {n="Savage Roar", t="missing", s={"52610:Savage Roar"}, slot="R", combat=true, below=3},
    {n="Predator's Swiftness", t="buff", s={"69369:Predator's Swiftness"}, slot="T"},
    {n="Rip / Rake on target", t="tdebuff", s={"1079:Rip","1822:Rake"}, slot="I", off=true, each=true, below=2},
    {n="Mangle on target", t="tdebuff", s={"33876:Mangle (Cat)","33878:Mangle (Bear)","46857:Trauma"}, slot="I", off=true, any=true, nk=true},
    {n="Tiger's Fury ready", t="cd", s={"5217:Tiger's Fury"}, slot="I", off=true},
  },
  ["Feral (bear)"] = {
    {n="Lacerate x5 on target", t="tstack", s={"33745:Lacerate"}, slot="L", max=5, below=3},
    {n="Demoralizing Roar on target", t="tdebuff", s={"99:Demoralizing Roar","1160:Demoralizing Shout"}, slot="I", any=true},
    {n="Savage Defense", t="missing", s={"62606:Savage Defense"}, slot="I", off=true, combat=true, nk=true},
    {n="Survival Instincts / Frenzied Regen ready", t="cd", s={"61336:Survival Instincts","22842:Frenzied Regeneration"}, slot="I", off=true},
  },
  Restoration = {
    {n="Lifebloom x3 on tank", t="fstack", s={"33763:Lifebloom"}, slot="L", max=3, below=2},
    {n="Tree of Life form missing", t="missing", s={"33891:Tree of Life"}, slot="R"},
    {n="Nature's Swiftness ready", t="cd", s={"17116:Nature's Swiftness"}, slot="T", off=true},
  },
},
}

-- Talent tab order per class (as returned by GetTalentTabInfo)
ns.SPECS = {
  WARRIOR = {"Arms","Fury","Protection"},
  PALADIN = {"Holy","Protection","Retribution"},
  HUNTER = {"Beast Mastery","Marksmanship","Survival"},
  ROGUE = {"Assassination","Combat","Subtlety"},
  PRIEST = {"Discipline","Holy","Shadow"},
  DEATHKNIGHT = {"Blood","Frost","Unholy"},
  SHAMAN = {"Elemental","Enhancement","Restoration"},
  MAGE = {"Arcane","Fire","Frost"},
  WARLOCK = {"Affliction","Demonology","Destruction"},
  DRUID = {"Balance","Feral","Restoration"},
}

-- Tabs shown in the Rules page
ns.SPEC_TABS = {}
for class, specs in pairs(ns.SPECS) do
  local t = {"All"}
  for _, s in ipairs(specs) do
    if s == "Feral" then t[#t+1] = "Feral (cat)"; t[#t+1] = "Feral (bear)" else t[#t+1] = s end
  end
  ns.SPEC_TABS[class] = t
end

local QUESTION = "Interface\\Icons\\INV_Misc_QuestionMark"
ns.QUESTION = QUESTION

local function parseSpells(list)
  local english = (GetLocale() == "enUS" or GetLocale() == "enGB")
  local set = {list = {}, names = {}, ids = {}}
  for _, s in ipairs(list or {}) do
    local id, fb = s:match("^(%d+):(.+)$")
    id = tonumber(id)
    local loc, _, icon = GetSpellInfo(id)
    local name = (english and fb) or loc or fb
    if english and fb then
      local _, _, i2 = GetSpellInfo(fb)
      icon = i2 or icon
    end
    set.list[#set.list + 1] = {id = id, name = name, icon = icon or QUESTION}
    set.names[#set.names + 1] = name
    set.ids[#set.ids + 1] = id
    if not set.icon then set.icon = icon end
  end
  set.icon = set.icon or QUESTION
  return set
end
ns.ParseSpells = parseSpells

local function compileSet(data, prefix, prioBase)
  if not data then return end
  for spec, rules in pairs(data) do
    for i, r in ipairs(rules) do
      r.id = prefix .. (r.n:lower():gsub("[^%w]", ""))
      r.spec = spec
      r.extra = (prefix ~= "") or nil
      r.defPrio = prioBase + i * 10
      r.set = parseSpells(r.s)
      if r.needT then r.needSet = parseSpells(r.needT) end
      if r.sated then r.satedSet = parseSpells(r.sated) end
      if r.choices then
        for _, ch in ipairs(r.choices) do
          if ch.s then ch.set = parseSpells(ch.s) end
        end
        if not r.s and r.choices[1].set then r.set = r.choices[1].set end
      end
    end
  end
end

function ns:CompileRules()
  compileSet(ns.RuleData[self.class], "", 0)
  compileSet(ns.ExtraData and ns.ExtraData[self.class], "x_", 1000)
end
